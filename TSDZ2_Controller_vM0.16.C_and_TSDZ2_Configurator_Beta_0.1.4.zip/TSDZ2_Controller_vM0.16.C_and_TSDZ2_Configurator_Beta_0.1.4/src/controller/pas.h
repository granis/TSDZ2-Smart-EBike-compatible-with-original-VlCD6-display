/*
 * TongSheng TSDZ2 motor controller firmware/
 *
 * Copyright (C) Casainho, 2018.
 *
 * Released under the GPL License, Version 3
 */

#ifndef _PAS_H_
#define _PAS_H_

#include "main.h"

void pas_init (void);
void pas2_init (void);

#endif /* _PAS_H_ */
