import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.io.*;
import java.awt.Desktop;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.JTextComponent;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ListSelectionModel;
import javax.swing.JLabel;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;
import java.awt.event.ActionListener;
import java.awt.GridLayout;
import java.awt.Font;
import java.awt.Color;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.SwingConstants;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JList;
import javax.swing.JScrollPane;
import java.awt.Dimension;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.DefaultListModel;
import javax.swing.event.ListDataListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.nio.file.Paths;
import java.util.Arrays;
import javax.swing.JCheckBox;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JPasswordField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.awt.Component;
import java.awt.Container;
import java.util.Enumeration;
import java.util.Vector;
import javax.swing.AbstractButton;
import javax.swing.border.Border;
import javax.swing.event.ChangeListener;
import java.util.Scanner;
import java.io.*;

public class OSEC extends JFrame
{
	public class FileContainer
	{
		public FileContainer(File file)
		{
			this.file = file;
		}
		public File file;

		@Override
		public String toString()
		{
			return file.getName();
		}
	}

	private JPanel contentPane;
	//----------------------------------------
	private JTextField TxtField01;
	private JTextField TxtField02;
	private JTextField TxtField03;
	private JTextField TxtField04;
	private JTextField TxtField05;
	private JTextField TxtField06;	
	private JTextField TxtField07;
	private JTextField TxtField08;
	private JTextField TxtField09;
	private JTextField TxtField10;
	private JTextField TxtField11;
	private JTextField TxtField12;
	private JTextField TxtField13;
	private JTextField TxtField14;
	private JTextField TxtField15;
	private JTextField TxtField16;
	private JTextField TxtField17;
	private JTextField TxtField18;
	private JTextField TxtField19;
	private JTextField TxtField20;
	private JTextField TxtField21;
	private JTextField TxtField22;
	private JTextField TxtField23;
	private JTextField TxtField24;
	private JTextField TxtField25;
	private JTextField TxtField26;
	private JTextField TxtField27;	
	private JTextField TxtField28;
	private JTextField TxtField29;
	private JTextField TxtField30;
	private JTextField TxtField31;
	private JTextField TxtField32;	
	private JTextField TxtField33;
	private JTextField TxtField34;
	private JTextField TxtField35;
	private JTextField TxtField36;
	private JTextField TxtField37;
	private JTextField TxtField38;
	private JTextField TxtField39;	
	private JTextField TxtField40;
	private JTextField TxtField41;
	private JTextField TxtField42;
	private JTextField TxtField43;
	private JTextField TxtField44;
	private JTextField TxtField45;
	private JTextField TxtField46;
	private JTextField TxtField47;
	private JTextField TxtField48;
	private JTextField TxtField49;
	private JTextField TxtField50;
	private JTextField TxtField51;
	private JTextField TxtField52;
	private JTextField TxtField53;
	private JTextField TxtField54;
	private JTextField TxtField55;
	private JTextField TxtField56;
	private JTextField TxtField57;
	private JTextField TxtField58;
	private JTextField TxtField59;
	private JTextField TxtField60;
	private JTextField TxtField61;
	private JTextField TxtField62;
	private JTextField TxtField63;
	private JTextField TxtField64;
	private JTextField TxtField65;
	private JTextField TxtField66;
	private JTextField TxtField67;
	private JTextField TxtField68;
	private JTextField TxtField69;
	private JTextField TxtField70;
	private JTextField TxtField71;
	private JTextField TxtField72;
	private JTextField TxtField73;
	private JTextField TxtField74;
	private JTextField TxtField75;
	private JTextField TxtField76;
	private JTextField TxtField77;
	private JTextField TxtField78;
	private JTextField TxtField79;
	private JTextField TxtField80;
	private JTextField TxtField81;
	private JTextField TxtField82;
	private JTextField TxtField83;
	private JTextField TxtField84;
	private JTextField TxtField85;
	private JTextField TxtField86;
	private JTextField TxtField87;
	private JTextField TxtField88;
	private JTextField TxtField89;
	private JTextField TxtField90;
	private JTextField TxtField91;
	private JTextField TxtField92;
	private JTextField TxtField93;
	private JTextField TxtField94;
	private JTextField TxtField95;
	private JTextField TxtField96;
	private JTextField TxtField97;
	private JTextField TxtField98;
	private JTextField TxtField99;
	private JTextField TxtField100;
	//----------------------------------------
	private JRadioButton rdbtnMot36V;
	private JRadioButton rdbtnMot48V;
	private JRadioButton rdbtnVLCD6;
	private JRadioButton rdbtnKTLCD3;
	private JRadioButton rdbtnBTooth;
	private JRadioButton rdbtnLights;
	private JRadioButton rdbtnBoost;
	private JRadioButton rdbtnOffroad;
	private JRadioButton rdbtnBoostSpeed;
	private JRadioButton rdbtnBoostCadence;
	//----------------------------------------
	private JCheckBox CheckBox01;
	private JCheckBox CheckBox02;
	private JCheckBox CheckBox03;
	private JCheckBox CheckBox04;
	private JCheckBox CheckBox05;
	private JCheckBox CheckBox06;
	private JCheckBox CheckBox07;
	private JCheckBox CheckBox08;
	private JCheckBox CheckBox09;
	private JCheckBox CheckBox10;
	private JCheckBox CheckBox11;
	private JCheckBox CheckBox12;
	private JCheckBox CheckBox13;
	private JCheckBox CheckBox14;
	private JCheckBox CheckBox15;
	//----------------------------------------
	private JCheckBox cbResetEeprom;
	private JCheckBox cbSaveIni;
	private JLabel lblOpenSourceFirmware;
	private JButton btnWriteConfiguration;
	//----------------------------------------
	private final ButtonGroup MotorType = new ButtonGroup();
	private final ButtonGroup DisplayType = new ButtonGroup();
	private final ButtonGroup ButtonLights = new ButtonGroup();
	private final ButtonGroup BoostState = new ButtonGroup();
	//----------------------------------------
	private File experimentalSettingsDir;
	private File lastSettingsFile = null;
	//----------------------------------------
	private int XOS = 40;
	private int YOS = 65;
	private int XL;
	private int YL;
	private int XT;
	private int YT;
	private int LBL;
	private int LBH;
	private int TXL;
	private int TXH;
	//----------------------------------------
	private String Version;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				try
				{
					OSEC frame = new OSEC();
					frame.setVisible(true);
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}
	
	public void loadSettings(File f) throws IOException
	{
		BufferedReader in = new BufferedReader(new FileReader(f));
		//--------------------------------------------------------------------
		rdbtnVLCD6.setSelected(Boolean.parseBoolean(in.readLine()));
		rdbtnKTLCD3.setSelected(Boolean.parseBoolean(in.readLine()));
		rdbtnBTooth.setSelected(Boolean.parseBoolean(in.readLine()));
		rdbtnLights.setSelected(Boolean.parseBoolean(in.readLine()));
		rdbtnBoost.setSelected(Boolean.parseBoolean(in.readLine()));
		rdbtnOffroad.setSelected(Boolean.parseBoolean(in.readLine()));
		CheckBox07.setSelected(Boolean.parseBoolean(in.readLine()));
		CheckBox04.setSelected(Boolean.parseBoolean(in.readLine()));
		CheckBox03.setSelected(Boolean.parseBoolean(in.readLine()));
		CheckBox09.setSelected(Boolean.parseBoolean(in.readLine()));
		CheckBox10.setSelected(Boolean.parseBoolean(in.readLine()));
		CheckBox11.setSelected(Boolean.parseBoolean(in.readLine()));
		CheckBox12.setSelected(Boolean.parseBoolean(in.readLine()));
		CheckBox08.setSelected(Boolean.parseBoolean(in.readLine()));
		rdbtnOffroad.setSelected(Boolean.parseBoolean(in.readLine()));
		CheckBox05.setSelected(Boolean.parseBoolean(in.readLine()));
		CheckBox06.setSelected(Boolean.parseBoolean(in.readLine()));
		CheckBox14.setSelected(Boolean.parseBoolean(in.readLine()));
		rdbtnBoostSpeed.setSelected(Boolean.parseBoolean(in.readLine()));
		rdbtnBoostCadence.setSelected(Boolean.parseBoolean(in.readLine()));
		//--------------------------------------------------------------------
		TxtField01.setText(in.readLine());
		TxtField02.setText(in.readLine());
		TxtField03.setText(in.readLine());
		TxtField04.setText(in.readLine());
		TxtField05.setText(in.readLine());
		TxtField06.setText(in.readLine());
		TxtField07.setText(in.readLine());
		TxtField08.setText(in.readLine());
		TxtField09.setText(in.readLine());
		TxtField10.setText(in.readLine());
		TxtField11.setText(in.readLine());
		TxtField12.setText(in.readLine());
		TxtField13.setText(in.readLine());
		TxtField14.setText(in.readLine());
		TxtField15.setText(in.readLine());
		TxtField16.setText(in.readLine());
		TxtField17.setText(in.readLine());
		TxtField18.setText(in.readLine());
		//--------------------------------------------------------------------
		rdbtnMot36V.setSelected(Boolean.parseBoolean(in.readLine()));
		rdbtnMot48V.setSelected(Boolean.parseBoolean(in.readLine()));
		CheckBox13.setSelected(Boolean.parseBoolean(in.readLine()));
		CheckBox01.setSelected(Boolean.parseBoolean(in.readLine()));
		TxtField19.setText(in.readLine());
		TxtField20.setText(in.readLine());
		TxtField21.setText(in.readLine());
		TxtField22.setText(in.readLine());
		TxtField23.setText(in.readLine());
		TxtField24.setText(in.readLine());
		TxtField25.setText(in.readLine());
		TxtField26.setText(in.readLine());
		TxtField27.setText(in.readLine());
		//--------------------------------------------------------------------
		TxtField28.setText(in.readLine());
		TxtField29.setText(in.readLine());
		TxtField30.setText(in.readLine());
		TxtField31.setText(in.readLine());
		TxtField32.setText(in.readLine());
		TxtField33.setText(in.readLine());
		TxtField34.setText(in.readLine());
		//--------------------------------------------------------------------
		TxtField35.setText(in.readLine());
		TxtField36.setText(in.readLine());
		TxtField37.setText(in.readLine());
		TxtField38.setText(in.readLine());
		TxtField39.setText(in.readLine());
		TxtField40.setText(in.readLine());
		TxtField41.setText(in.readLine());
		TxtField42.setText(in.readLine());
		TxtField43.setText(in.readLine());
		TxtField44.setText(in.readLine());
		TxtField45.setText(in.readLine());
		//--------------------------------------------------------------------
		TxtField47.setText(in.readLine());
		TxtField48.setText(in.readLine());
		TxtField49.setText(in.readLine());
		//--------------------------------------------------------------------
		TxtField61.setText(in.readLine());
		TxtField62.setText(in.readLine());
		TxtField63.setText(in.readLine());
		TxtField65.setText(in.readLine());
		TxtField66.setText(in.readLine());
		//--------------------------------------------------------------------
		TxtField55.setText(in.readLine());
		TxtField56.setText(in.readLine());
		TxtField57.setText(in.readLine());
		TxtField58.setText(in.readLine());		
		//--------------------------------------------------------------------
		TxtField50.setText(in.readLine());
		TxtField51.setText(in.readLine());
		TxtField52.setText(in.readLine());
		TxtField53.setText(in.readLine());
		TxtField54.setText(in.readLine());		
		//--------------------------------------------------------------------
		TxtField68.setText(in.readLine());
		TxtField69.setText(in.readLine());
		TxtField70.setText(in.readLine());
		TxtField71.setText(in.readLine());
		TxtField72.setText(in.readLine());
		TxtField73.setText(in.readLine());
		TxtField74.setText(in.readLine());
		TxtField53.setText(in.readLine());
		TxtField54.setText(in.readLine());		
		//--------------------------------------------------------------------
		TxtField75.setText(in.readLine());
		TxtField76.setText(in.readLine());
		//--------------------------------------------------------------------
		CheckBox02.setSelected(Boolean.parseBoolean(in.readLine()));		
		TxtField77.setText(in.readLine());
		TxtField78.setText(in.readLine());
		TxtField79.setText(in.readLine());
		TxtField80.setText(in.readLine());
		TxtField81.setText(in.readLine());
		TxtField82.setText(in.readLine());
		//--------------------------------------------------------------------
		TxtField83.setText(in.readLine());
		TxtField84.setText(in.readLine());

		in.close();
	}
	
	private void updateDependiencies()
	{
		// VLCD6 enabled?
		if (rdbtnVLCD6.isSelected())
		{
			TxtField02.setEditable(true);
			TxtField04.setEditable(true);
			TxtField06.setEditable(true);
			//-----------------------------
			TxtField08.setEditable(true);
			TxtField09.setEditable(true);
			TxtField10.setEditable(true);
			TxtField11.setEditable(true);
			TxtField12.setEditable(true);
			TxtField13.setEditable(true);
			TxtField14.setEditable(true);
			TxtField15.setEditable(true);
			TxtField16.setEditable(true);
			//-----------------------------			
			TxtField35.setEditable(true);
			TxtField36.setEditable(true);
			//-----------------------------
			TxtField37.setEditable(true);
			//-----------------------------
			TxtField62.setEditable(true);
			TxtField63.setEditable(true);
			//TxtField64.setEditable(true);
			TxtField65.setEditable(true);
			TxtField66.setEditable(true);
			//-----------------------------
			TxtField68.setEditable(true);
			TxtField69.setEditable(true);
			TxtField70.setEditable(true);
			TxtField71.setEditable(true);
			TxtField72.setEditable(true);
			TxtField73.setEditable(true);
			TxtField74.setEditable(true);
			TxtField53.setEditable(true);
			TxtField54.setEditable(true);			
			//-----------------------------			
			TxtField75.setEditable(true);
			TxtField76.setEditable(true);			
			//-----------------------------		
			TxtField77.setEditable(true);
			TxtField78.setEditable(true);
			TxtField79.setEditable(true);
			TxtField80.setEditable(true);
			TxtField81.setEditable(true);
			TxtField82.setEditable(true);
			//-----------------------------			
			TxtField85.setEditable(true);
			TxtField86.setEditable(true);
			TxtField87.setEditable(true);
			//-----------------------------
			CheckBox05.setForeground(Color.DARK_GRAY);
			CheckBox06.setForeground(Color.DARK_GRAY);
			CheckBox07.setForeground(Color.DARK_GRAY);
			CheckBox08.setForeground(Color.DARK_GRAY);
			CheckBox09.setForeground(Color.DARK_GRAY);
			CheckBox10.setForeground(Color.DARK_GRAY);
			CheckBox11.setForeground(Color.DARK_GRAY);
			CheckBox12.setForeground(Color.DARK_GRAY);
			CheckBox14.setForeground(Color.WHITE);
			//-----------------------------
			rdbtnLights.setForeground(Color.WHITE);
			rdbtnBoost.setForeground(Color.DARK_GRAY);
			rdbtnOffroad.setForeground(Color.DARK_GRAY);
			rdbtnBoostSpeed.setForeground(Color.DARK_GRAY);	
			rdbtnBoostCadence.setForeground(Color.DARK_GRAY);
			//-----------------------------
			// VLCD6 always on?
			if (CheckBox08.isSelected())
			{
				CheckBox11.setSelected(false);
				CheckBox12.setSelected(false);
			}
			
			// Wheel perimeter flag enabled?
			if (CheckBox09.isSelected())
			{
				TxtField35.setEditable(false);
			}

			// Wheel max speed flag enabled?
			if (CheckBox10.isSelected())
			{
				TxtField36.setEditable(false);
			}			

			// Motor working flag enabled?
			if (CheckBox11.isSelected())
			{
				CheckBox08.setSelected(false);
			}
			
			// Wheel turning flag enabled?
			if (CheckBox12.isSelected())
			{
				CheckBox08.setSelected(false);
			}
			
			// Walk assist enabled?
			if (!CheckBox07.isSelected())
			{
				TxtField68.setEditable(false);
				TxtField69.setEditable(false);
				TxtField70.setEditable(false);
				TxtField71.setEditable(false);
				TxtField72.setEditable(false);
				TxtField73.setEditable(false);
				TxtField74.setEditable(false);
				TxtField53.setEditable(false);
				TxtField54.setEditable(false);				
			}
			
			// Offroad disabled?
			if (!rdbtnOffroad.isSelected())
			{
				TxtField75.setEditable(false);
				TxtField76.setEditable(false);
				CheckBox05.setForeground(Color.LIGHT_GRAY);
				CheckBox06.setForeground(Color.LIGHT_GRAY);				
			}			
			
			// Motor power boost disabled?
			if (!rdbtnBoost.isSelected()) 
			{
				TxtField77.setEditable(false);
				TxtField78.setEditable(false);
				TxtField79.setEditable(false);
				TxtField80.setEditable(false);
				TxtField81.setEditable(false);
				TxtField82.setEditable(false);
				rdbtnBoostSpeed.setForeground(Color.LIGHT_GRAY);
				rdbtnBoostCadence.setForeground(Color.LIGHT_GRAY);				
			}			

			// Temperature Limit disabled?
			if (!CheckBox14.isSelected())
			{
				TxtField85.setEditable(false);
				TxtField86.setEditable(false);
				TxtField87.setEditable(false);
			}
		}
		// KT-LCD3 enabled?
		else if (rdbtnKTLCD3.isSelected()) 
		{
			TxtField02.setEditable(false);
			TxtField04.setEditable(false);
			TxtField06.setEditable(false);
			//-----------------------------
			TxtField08.setEditable(false);
			TxtField09.setEditable(false);
			TxtField10.setEditable(false);
			TxtField11.setEditable(false);
			TxtField12.setEditable(false);
			TxtField13.setEditable(false);
			TxtField14.setEditable(false);
			TxtField15.setEditable(false);
			TxtField16.setEditable(false);
			//-----------------------------
			TxtField35.setEditable(true);
			TxtField36.setEditable(true);
			//-----------------------------
			TxtField37.setEditable(false);
			//-----------------------------
			TxtField62.setEditable(false);
			TxtField63.setEditable(false);
			//TxtField64.setEditable(false);
			TxtField65.setEditable(false);
			TxtField66.setEditable(false);
			//-----------------------------
			TxtField68.setEditable(false);
			TxtField69.setEditable(false);
			TxtField70.setEditable(false);
			TxtField71.setEditable(false);
			TxtField72.setEditable(false);
			TxtField73.setEditable(false);
			TxtField74.setEditable(false);
			TxtField53.setEditable(false);
			TxtField54.setEditable(false);			
			//-----------------------------			
			TxtField75.setEditable(true);
			TxtField76.setEditable(true);
			//-----------------------------		
			TxtField77.setEditable(false);
			TxtField78.setEditable(false);
			TxtField79.setEditable(false);
			TxtField80.setEditable(false);
			TxtField81.setEditable(false);
			TxtField82.setEditable(false);
			//-----------------------------			
			TxtField85.setEditable(false);
			TxtField86.setEditable(false);
			TxtField87.setEditable(false);
			//-----------------------------
			CheckBox05.setForeground(Color.LIGHT_GRAY);
			CheckBox06.setForeground(Color.LIGHT_GRAY);
			CheckBox07.setForeground(Color.LIGHT_GRAY);
			CheckBox08.setForeground(Color.LIGHT_GRAY);
			CheckBox09.setForeground(Color.LIGHT_GRAY);
			CheckBox10.setForeground(Color.LIGHT_GRAY);
			CheckBox11.setForeground(Color.LIGHT_GRAY);
			CheckBox12.setForeground(Color.LIGHT_GRAY);
			CheckBox14.setForeground(Color.LIGHT_GRAY);
			//-----------------------------
			rdbtnLights.setForeground(Color.LIGHT_GRAY);
			rdbtnBoost.setForeground(Color.LIGHT_GRAY);
			rdbtnOffroad.setForeground(Color.LIGHT_GRAY);
			rdbtnBoostSpeed.setForeground(Color.LIGHT_GRAY);
			rdbtnBoostCadence.setForeground(Color.LIGHT_GRAY);
		}
		// BlueTooth enabled?
		else if (rdbtnBTooth.isSelected())
		{
			rdbtnVLCD6.setSelected(true);			
		}

		// Throttle enabled?
		if (CheckBox03.isSelected())
		{
			TxtField55.setEditable(true);
			TxtField56.setEditable(true);
			TxtField57.setEditable(true);
			TxtField58.setEditable(true);
		}
		else
		{
			TxtField55.setEditable(false);
			TxtField56.setEditable(false);
			TxtField57.setEditable(false);
			TxtField58.setEditable(false);
		}	
	}
	
	/**
	 * Create the frame.
	 *
	 * @throws IOException
	 */
	public OSEC() throws IOException
	{
		//-------------------------
		Version = "0.1.2";
		//-------------------------
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 3, 1366, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel Note = new JLabel("Note: Colored fields used by VLCD6 selection");
		Note.setBounds(XOS+900, 20, 400, 29);
		Note.setForeground(Color.BLUE);
		contentPane.add(Note);
		
		JLabel lblTollesProgramm = new JLabel("TDSZ2 Controller's Parameters Configurator ver. " + Version + " (by marcoq)");
		lblTollesProgramm.setHorizontalAlignment(SwingConstants.LEFT);
		lblTollesProgramm.setForeground(Color.GRAY);
		lblTollesProgramm.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblTollesProgramm.setBounds(XOS, 20, 530, 34);
		contentPane.add(lblTollesProgramm);
		
		/*
		lblOpenSourceFirmware = new JLabel("Open Source Configurator for TSDZ2-Smart-EBike Controller's Parameters");
		lblOpenSourceFirmware.setHorizontalAlignment(SwingConstants.LEFT);
		lblOpenSourceFirmware.setFont(new Font("Tahoma", Font.PLAIN, 11));
		lblOpenSourceFirmware.setForeground(Color.BLUE);
		lblOpenSourceFirmware.setBounds(XOS, 42, 400, 14);
		contentPane.add(lblOpenSourceFirmware);*/
		
		//-------------------------------------------------------------------------
		JButton btnMarcoq = new JButton("Project Repository");
		btnMarcoq.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				if (Desktop.isDesktopSupported())
				{
					try
					{
						Desktop.getDesktop().browse(new URI("https://github.com/qmarco/TSDZ2-Smart-EBike-compatible-with-original-VlCD6-display"));
					} catch (Exception e) {}
				} 
			}
		});
		btnMarcoq.setForeground(Color.BLUE);
		btnMarcoq.setBounds(XOS+540, 20, 160, 29);
		contentPane.add(btnMarcoq);	
		
		//-------------------------------------------------------------------------
		JButton btnStancecoke = new JButton("Tanks to stancecoke!");
		btnStancecoke.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				if (Desktop.isDesktopSupported())
				{
					try
					{
						Desktop.getDesktop().browse(new URI("https://github.com/stancecoke/BMSBattery_S_controllers_firmware"));
					} catch (Exception e) {}
				} 
			}
		});
		btnStancecoke.setForeground(Color.BLUE);
		btnStancecoke.setBounds(XOS+720, 20, 160, 29);
		contentPane.add(btnStancecoke);
		
		//-------------------------------------------------------------------------
		JButton btnHelpDocument = new JButton("Help");
		btnHelpDocument.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				try 
				{
					Desktop desktop = null;
					if (Desktop.isDesktopSupported())
					{
						desktop = Desktop.getDesktop();
					}

					desktop.open(new File("help_document.pdf"));
				} 
				catch (IOException ioe)
				{
					ioe.printStackTrace();
				}					
			}
		});
		btnHelpDocument.setForeground(Color.BLUE);
		btnHelpDocument.setBounds(XOS+1190, 20, 70, 29);
		contentPane.add(btnHelpDocument);
		
		//-------------------------------------------------------------------------	
		experimentalSettingsDir = new File(Paths.get(".").toAbsolutePath().normalize().toString());
		while (!Arrays.asList(experimentalSettingsDir.list()).contains("experimental settings"))
		{
			experimentalSettingsDir = experimentalSettingsDir.getParentFile();
		}
		File provenSettingsDir = new File(experimentalSettingsDir.getAbsolutePath() + File.separator + "proven settings");
		experimentalSettingsDir = new File(experimentalSettingsDir.getAbsolutePath() + File.separator + "experimental settings");
		
		DefaultListModel provenSettingsFilesModel = new DefaultListModel();
		DefaultListModel experimentalSettingsFilesModel = new DefaultListModel();
		
		for (File file : experimentalSettingsDir.listFiles())
		{
			experimentalSettingsFilesModel.addElement(new FileContainer(file));
		}
		
		for (File file : provenSettingsDir.listFiles())
		{
			provenSettingsFilesModel.addElement(new FileContainer(file));

			if (lastSettingsFile == null)
			{
				lastSettingsFile = file;
			} 
			else
			{
				if (file.getName().compareTo(lastSettingsFile.getName()) > 0)
				{
					lastSettingsFile = file;
				}
			}
		}

		JLabel lblES = new JLabel("Proven Settings");
		lblES.setBounds(XOS+960, YOS+368, 320, 20);
		lblES.setForeground(Color.RED);
		contentPane.add(lblES);
		
		JLabel lblPS = new JLabel("Experimental Settings");
		lblPS.setBounds(XOS+960, YOS+470, 320, 20);
		lblPS.setForeground(Color.RED);
		contentPane.add(lblPS);
		
		JList provenSettingsList = new JList(provenSettingsFilesModel);
		provenSettingsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		provenSettingsList.setLayoutOrientation(JList.VERTICAL);
		provenSettingsList.setVisibleRowCount(-1);

		JScrollPane provenListScroller = new JScrollPane(provenSettingsList);
		provenListScroller.setPreferredSize(new Dimension(280, 120));
		provenListScroller.setBounds(XOS+960, YOS+388, 300, 80);
		contentPane.add(provenListScroller);

		JList experimentalSettingsList = new JList(experimentalSettingsFilesModel);
		experimentalSettingsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		experimentalSettingsList.setLayoutOrientation(JList.VERTICAL);
		experimentalSettingsList.setVisibleRowCount(-1);

		JScrollPane expListScroller = new JScrollPane(experimentalSettingsList);
		expListScroller.setPreferredSize(new Dimension(280, 120));
		expListScroller.setBounds(XOS+960, YOS+490, 300, 80);
		contentPane.add(expListScroller);

		provenSettingsList.addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseClicked(MouseEvent e)
			{
				try
				{
					provenSettingsList.getSelectedValue();
					loadSettings(((FileContainer) provenSettingsList.getSelectedValue()).file);
					provenSettingsList.clearSelection();
				} 
				catch (IOException ex)
				{
					Logger.getLogger(OSEC.class.getName()).log(Level.SEVERE, null, ex);
				}
				provenSettingsList.clearSelection();
				updateDependiencies();
			}
		});
		
		experimentalSettingsList.addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseClicked(MouseEvent e)
			{
				try
				{
					experimentalSettingsList.getSelectedValue();
					loadSettings(((FileContainer) experimentalSettingsList.getSelectedValue()).file);
					experimentalSettingsList.clearSelection();
				} 
				catch (IOException ex)
				{
					Logger.getLogger(OSEC.class.getName()).log(Level.SEVERE, null, ex);
				}
				experimentalSettingsList.clearSelection();
				updateDependiencies();
			}
		});
		
		//=============================================================================================
		// BATTERY
		//=============================================================================================
		XL = XOS;
		YL = YOS;
		XT = XOS+235;
		YT = YOS;
		LBL = 300;
		LBH = 14;
		TXL = 50;
		TXH = 20;		
		//-------------------------------------------------------------------------
		JLabel LabelBattery = new JLabel("BATTERY :");
		LabelBattery.setBounds(XL+0, YL+0, LBL, LBH); // (X, Y, L, H)
		LabelBattery.setForeground(Color.RED);
		//LabelBattery.setForeground(Color.GRAY);
		contentPane.add(LabelBattery);
		//-------------------------------------------------------------------------
		JLabel Label01 = new JLabel("Max Battery Current Limit (Amp)");
		Label01.setBounds(XL+0, YL+20, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label01);

		TxtField01 = new JTextField();
		TxtField01.setText("17.5");
		TxtField01.setBounds(XT+0, YT+20, TXL, TXH); // (X, Y, L, H)
		contentPane.add(TxtField01);
		TxtField01.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label02 = new JLabel("Max Battery Power (Watt)");
		Label02.setBounds(XL+0, YL+40, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label02);

		TxtField02 = new JTextField();
		TxtField02.setText("625");
		TxtField02.setBounds(XT+0, YT+40, TXL, TXH); // (X, Y, L, H)
		TxtField02.setBackground(Color.YELLOW);
		contentPane.add(TxtField02);
		TxtField02.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label03 = new JLabel("Max Battery Current (Amp)");
		Label03.setBounds(XL+0, YL+60, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label03);

		TxtField03 = new JTextField();
		TxtField03.setText("17.0");
		TxtField03.setBounds(XT+0, YT+60, TXL, TXH); // (X, Y, L, H)
		contentPane.add(TxtField03);
		TxtField03.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label04 = new JLabel("Battery Cells Number (7 ... 14)");
		Label04.setBounds(XL+0, YL+80, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label04);

		TxtField04 = new JTextField();
		TxtField04.setText("10");
		TxtField04.setBounds(XT+0, YT+80, TXL, TXH); // (X, Y, L, H)
		TxtField04.setBackground(Color.YELLOW);
		contentPane.add(TxtField04);
		TxtField04.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label05 = new JLabel("Battery Low Voltage Cut-Off");
		Label05.setBounds(XL+0, YL+100, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label05);

		TxtField05 = new JTextField();
		TxtField05.setText("29.0");
		TxtField05.setBounds(XT+0, YT+100, TXL, TXH); // (X, Y, L, H)
		contentPane.add(TxtField05);
		TxtField05.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label06 = new JLabel("Battery Pack Resistance (milli Ohm)");
		Label06.setBounds(XL+0, YL+120, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label06);

		TxtField06 = new JTextField();
		TxtField06.setText("196");
		TxtField06.setBounds(XT+0, YT+120, TXL, TXH); // (X, Y, L, H)
		TxtField06.setBackground(Color.YELLOW);
		contentPane.add(TxtField06);
		TxtField06.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label07 = new JLabel("Battery Voltage for FOC calc. (Volt)");
		Label07.setBounds(XL+0, YL+140, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label07);

		TxtField07 = new JTextField();
		TxtField07.setText("36.0");
		TxtField07.setBounds(XT+0, YT+140, TXL, TXH); // (X, Y, L, H)
		contentPane.add(TxtField07);
		TxtField07.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label08 = new JLabel("Li-Ion Cell Volt at 100% (Volt)");
		Label08.setBounds(XL+0, YL+160, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label08);

		TxtField08 = new JTextField();
		TxtField08.setText("4.25");
		TxtField08.setBounds(XT+0, YT+160, TXL, TXH); // (X, Y, L, H)
		TxtField08.setBackground(Color.YELLOW);
		contentPane.add(TxtField08);
		TxtField08.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label09 = new JLabel("Li-Ion Cell Volt at 83% (Volt)");
		Label09.setBounds(XL+0, YL+180, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label09);

		TxtField09 = new JTextField();
		TxtField09.setText("3.96");
		TxtField09.setBounds(XT+0, YT+180, TXL, TXH); // (X, Y, L, H)
		TxtField09.setBackground(Color.YELLOW);
		contentPane.add(TxtField09);
		TxtField09.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label10 = new JLabel("Li-Ion Cell Volt at 50% (Volt)");
		Label10.setBounds(XL+0, YL+200, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label10);

		TxtField10 = new JTextField();
		TxtField10.setText("3.70");
		TxtField10.setBounds(XT+0, YT+200, TXL, TXH); // (X, Y, L, H)
		TxtField10.setBackground(Color.YELLOW);
		contentPane.add(TxtField10);
		TxtField10.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label11 = new JLabel("Li-Ion Cell Volt at 17% (Volt)");
		Label11.setBounds(XL+0, YL+220, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label11);

		TxtField11 = new JTextField();
		TxtField11.setText("3.44");
		TxtField11.setBounds(XT+0, YT+220, TXL, TXH); // (X, Y, L, H)
		TxtField11.setBackground(Color.YELLOW);
		contentPane.add(TxtField11);
		TxtField11.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label12 = new JLabel("Li-Ion Cell Volt at 10% (Volt)");
		Label12.setBounds(XL+0, YL+240, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label12);

		TxtField12 = new JTextField();
		TxtField12.setText("3.30");
		TxtField12.setBounds(XT+0, YT+240, TXL, TXH); // (X, Y, L, H)
		TxtField12.setBackground(Color.YELLOW);
		contentPane.add(TxtField12);
		TxtField12.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label13 = new JLabel("Li-Ion Cell Volt at 0% (Volt)");
		Label13.setBounds(XL+0, YL+260, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label13);

		TxtField13 = new JTextField();
		TxtField13.setText("3.00");
		TxtField13.setBounds(XT+0, YT+260, TXL, TXH); // (X, Y, L, H)
		TxtField13.setBackground(Color.YELLOW);
		contentPane.add(TxtField13);
		TxtField13.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label14 = new JLabel("SOC Battery Voltage Filter Coefficient");
		Label14.setBounds(XL+0, YL+280, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label14);

		TxtField14 = new JTextField();
		TxtField14.setText("4");
		TxtField14.setBounds(XT+0, YT+280, TXL, TXH); // (X, Y, L, H)
		TxtField14.setBackground(Color.YELLOW);
		contentPane.add(TxtField14);
		TxtField14.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label15 = new JLabel("SOC Battery Current Filter Coefficient");
		Label15.setBounds(XL+0, YL+300, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label15);

		TxtField15 = new JTextField();
		TxtField15.setText("4");
		TxtField15.setBounds(XT+0, YT+300, TXL, TXH); // (X, Y, L, H)
		TxtField15.setBackground(Color.YELLOW);
		contentPane.add(TxtField15);
		TxtField15.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label16 = new JLabel("SOC ADC Battery per ADC step (Volt)");
		Label16.setBounds(XL+0, YL+320, LBL, LBH); // (X, Y, L, H)
		Label16.setForeground(Color.GRAY);
		contentPane.add(Label16);

		TxtField16 = new JTextField();
		TxtField16.setText("0.0866");
		TxtField16.setBounds(XT+0, YT+320, TXL, TXH); // (X, Y, L, H)
		TxtField16.setBackground(Color.YELLOW);
		TxtField16.setForeground(Color.GRAY);
		contentPane.add(TxtField16);
		TxtField16.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label17 = new JLabel("MOT Battery Voltage Filter Coefficient");
		Label17.setBounds(XL+0, YL+340, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label17);

		TxtField17 = new JTextField();
		TxtField17.setText("2");
		TxtField17.setBounds(XT+0, YT+340, TXL, TXH); // (X, Y, L, H)
		contentPane.add(TxtField17);
		TxtField17.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label18 = new JLabel("MOT Battery Current Filter Coefficient");
		Label18.setBounds(XL+0, YL+360, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label18);

		TxtField18 = new JTextField();
		TxtField18.setText("2");
		TxtField18.setBounds(XT+0, YT+360, TXL, TXH); // (X, Y, L, H)
		contentPane.add(TxtField18);
		TxtField18.setColumns(10);
		
		//=============================================================================================
		// MOTOR
		//=============================================================================================
		XL = XOS;
		YL = YL+360+30;
		XT = XOS+235;
		YT = YT+360+30;	
		LBL = 300;
		LBH = 14;
		TXL = 50;
		TXH = 20;		
		//-------------------------------------------------------------------------
		JLabel LabelMotor = new JLabel("MOTOR :");
		LabelMotor.setBounds(XL+0, YL+0, LBL, LBH); // (X, Y, L, H)
		LabelMotor.setForeground(Color.RED);
		//Label10.setForeground(Color.GRAY);
		contentPane.add(LabelMotor);
		//-------------------------------------------------------------------------
		rdbtnMot36V = new JRadioButton("Motor 36V");
		rdbtnMot36V.setSelected(true);
		MotorType.add(rdbtnMot36V);
		rdbtnMot36V.setBounds(XL+0, YL+20, 100, 20); // (X, Y, L, H)
		contentPane.add(rdbtnMot36V);	
		
		rdbtnMot48V = new JRadioButton("Motor 48V");
		rdbtnMot48V.setSelected(false);
		MotorType.add(rdbtnMot48V);
		rdbtnMot48V.setBounds(XL+100, YL+20, 100, 20);
		contentPane.add(rdbtnMot48V);
		//-------------------------------------------------------------------------
		CheckBox13 = new JCheckBox("Experimental High Cadence Mode");
		CheckBox13.setSelected(false);
		CheckBox13.setBounds(XL+0, YL+40, 250, 20);
		contentPane.add(CheckBox13);		
		//-------------------------------------------------------------------------
		CheckBox01 = new JCheckBox("Assistance Without Pedal Rotation");
		CheckBox01.setSelected(false);
		CheckBox01.setBounds(XL+0, YL+60, 250, 20);
		contentPane.add(CheckBox01);		
		//-------------------------------------------------------------------------
		JLabel Label19 = new JLabel("Max Motor Power (Watt)");
		Label19.setBounds(XL+0, YL+80, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label19);

		TxtField19 = new JTextField();
		TxtField19.setText("250");
		TxtField19.setBounds(XT+0, YT+80, TXL, TXH); // (X, Y, L, H)
		contentPane.add(TxtField19);
		TxtField19.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label20 = new JLabel("Motor Phase Max Current (Amp)");
		Label20.setBounds(XL+0, YL+100, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label20);

		TxtField20 = new JTextField();
		TxtField20.setText("30.0");
		TxtField20.setBounds(XT+0, YT+100, TXL, TXH); // (X, Y, L, H)
		contentPane.add(TxtField20);
		TxtField20.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label21 = new JLabel("Motor Rotor Offset Angle (Degree)");
		Label21.setBounds(XL+0, YL+120, LBL, LBH); // (X, Y, L, H)
		Label21.setForeground(Color.GRAY);
		contentPane.add(Label21);

		TxtField21 = new JTextField();
		TxtField21.setText("10");
		TxtField21.setBounds(XT+0, YT+120, TXL, TXH); // (X, Y, L, H)
		TxtField21.setForeground(Color.GRAY);
		contentPane.add(TxtField21);
		TxtField21.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label22 = new JLabel("Motor Rotor ERPS Interpolation 60 deg.");
		Label22.setBounds(XL+0, YL+140, LBL, LBH); // (X, Y, L, H)
		Label22.setForeground(Color.GRAY);
		contentPane.add(Label22);

		TxtField22 = new JTextField();
		TxtField22.setText("10");
		TxtField22.setBounds(XT+0, YT+140, TXL, TXH); // (X, Y, L, H)
		TxtField22.setForeground(Color.GRAY);
		contentPane.add(TxtField22);
		TxtField22.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label23 = new JLabel("Motor Over Speed ERPS");
		Label23.setBounds(XL+0, YL+160, LBL, LBH); // (X, Y, L, H)
		Label23.setForeground(Color.GRAY);
		contentPane.add(Label23);

		TxtField23 = new JTextField();
		TxtField23.setText("520");
		TxtField23.setBounds(XT+0, YT+160, TXL, TXH); // (X, Y, L, H)
		TxtField23.setForeground(Color.GRAY);
		contentPane.add(TxtField23);
		TxtField23.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label24 = new JLabel("Motor Over Speed ERPS Experimental");
		Label24.setBounds(XL+0, YL+180, LBL, LBH); // (X, Y, L, H)
		Label24.setForeground(Color.GRAY);
		contentPane.add(Label24);

		TxtField24 = new JTextField();
		TxtField24.setText("700");
		TxtField24.setBounds(XT+0, YT+180, TXL, TXH); // (X, Y, L, H)
		TxtField24.setForeground(Color.GRAY);
		contentPane.add(TxtField24);
		TxtField24.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label25 = new JLabel("Reserved");
		Label25.setBounds(XL+0, YL+200, LBL, LBH); // (X, Y, L, H)
		Label25.setForeground(Color.GRAY);
		contentPane.add(Label25);

		TxtField25 = new JTextField();
		TxtField25.setText("0");
		TxtField25.setBounds(XT+0, YT+200, TXL, TXH); // (X, Y, L, H)
		TxtField25.setEditable(false);
		//TxtField25.setBackground(Color.LIGHT_GRAY);
		TxtField25.setForeground(Color.GRAY);
		contentPane.add(TxtField25);
		TxtField25.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label26 = new JLabel("Reserved");
		Label26.setBounds(XL+0, YL+220, LBL, LBH); // (X, Y, L, H)
		Label26.setForeground(Color.GRAY);
		contentPane.add(Label26);

		TxtField26 = new JTextField();
		TxtField26.setText("0");
		TxtField26.setBounds(XT+0, YT+220, TXL, TXH); // (X, Y, L, H)
		TxtField26.setEditable(false);
		//TxtField26.setBackground(Color.LIGHT_GRAY);
		TxtField26.setForeground(Color.GRAY);
		contentPane.add(TxtField26);
		TxtField26.setColumns(10);
		//-------------------------------------------------------------------------
		/*
		JLabel Label27 = new JLabel("Reserved");
		Label27.setBounds(XL+0, YL+240, LBL, LBH); // (X, Y, L, H)
		Label27.setForeground(Color.GRAY);
		contentPane.add(Label27);

		TxtField27 = new JTextField();
		TxtField27.setText("0");
		TxtField27.setBounds(XT+0, YT+240, TXL, TXH); // (X, Y, L, H)
		TxtField27.setEditable(false);
		//TxtField27.setBackground(Color.LIGHT_GRAY);
		TxtField27.setForeground(Color.GRAY);
		contentPane.add(TxtField27);
		TxtField27.setColumns(10);*/

		//=============================================================================================
		// PWM DUTY CYCLE
		//=============================================================================================
		XL = XOS+320;
		YL = YOS;
		XT = XOS+235+320;
		YT = YOS;
		LBL = 300;
		LBH = 14;
		TXL = 50;
		TXH = 20;	
		//-------------------------------------------------------------------------
		JLabel LabelPwmDutyCycle = new JLabel("PWM DUTY CYCLE :");
		LabelPwmDutyCycle.setBounds(XL+0, YL+0, LBL, LBH); // (X, Y, L, H)
		LabelPwmDutyCycle.setForeground(Color.RED);
		//LabelPwmDutyCycle.setForeground(Color.GRAY);
		contentPane.add(LabelPwmDutyCycle);
		//-------------------------------------------------------------------------
		JLabel Label28 = new JLabel("PWM Frequency (Hertz)");
		Label28.setBounds(XL+0, YL+20, LBL, LBH); // (X, Y, L, H)
		Label28.setForeground(Color.GRAY);
		contentPane.add(Label28);

		TxtField28 = new JTextField();
		TxtField28.setText("15625");
		TxtField28.setBounds(XT+0, YT+20, TXL, TXH); // (X, Y, L, H)
		TxtField28.setForeground(Color.GRAY);
		contentPane.add(TxtField28);
		TxtField28.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label29 = new JLabel("PWM Duty Cycle Min (0 ... 255)");
		Label29.setBounds(XL+0, YL+40, LBL, LBH); // (X, Y, L, H)
		Label29.setForeground(Color.GRAY);
		contentPane.add(Label29);

		TxtField29 = new JTextField();
		TxtField29.setText("20");
		TxtField29.setBounds(XT+0, YT+40, TXL, TXH); // (X, Y, L, H)
		TxtField29.setForeground(Color.GRAY);
		contentPane.add(TxtField29);
		TxtField29.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label30 = new JLabel("PWM Duty Cycle Max (0 ... 255)");
		Label30.setBounds(XL+0, YL+60, LBL, LBH); // (X, Y, L, H)
		Label30.setForeground(Color.GRAY);
		contentPane.add(Label30);

		TxtField30 = new JTextField();
		TxtField30.setText("254");
		TxtField30.setBounds(XT+0, YT+60, TXL, TXH); // (X, Y, L, H)
		TxtField30.setForeground(Color.GRAY);
		contentPane.add(TxtField30);
		TxtField30.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label31 = new JLabel("PWM Duty Cycle Ramp Up (milliSec)");
		Label31.setBounds(XL+0, YL+80, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label31);

		TxtField31 = new JTextField();
		TxtField31.setText("2.5");
		TxtField31.setBounds(XT+0, YT+80, TXL, TXH); // (X, Y, L, H)
		contentPane.add(TxtField31);
		TxtField31.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label32 = new JLabel("PWM Duty Cycle Ramp Dw (milliSec)");
		Label32.setBounds(XL+0, YL+100, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label32);

		TxtField32 = new JTextField();
		TxtField32.setText("2.5");
		TxtField32.setBounds(XT+0, YT+100, TXL, TXH); // (X, Y, L, H)
		contentPane.add(TxtField32);
		TxtField32.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label33 = new JLabel("Reserved");
		Label33.setBounds(XL+0, YL+120, LBL, LBH); // (X, Y, L, H)
		Label33.setForeground(Color.GRAY);
		contentPane.add(Label33);

		TxtField33 = new JTextField();
		TxtField33.setText("0");
		TxtField33.setBounds(XT+0, YT+120, TXL, TXH); // (X, Y, L, H)
		TxtField33.setEditable(false);
		//TxtField33.setBackground(Color.LIGHT_GRAY);
		TxtField33.setForeground(Color.GRAY);
		contentPane.add(TxtField33);
		TxtField33.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label34 = new JLabel("Reserved");
		Label34.setBounds(XL+0, YL+140, LBL, LBH); // (X, Y, L, H)
		Label34.setForeground(Color.GRAY);
		contentPane.add(Label34);

		TxtField34 = new JTextField();
		TxtField34.setText("0");
		TxtField34.setBounds(XT+0, YT+140, TXL, TXH); // (X, Y, L, H)
		TxtField34.setEditable(false);
		//TxtField34.setBackground(Color.LIGHT_GRAY);
		TxtField34.setForeground(Color.GRAY);
		contentPane.add(TxtField34);
		TxtField34.setColumns(10);

		//=============================================================================================
		// WHEEL
		//=============================================================================================
		XL = XOS+320;
		YL = YL+140+30;
		XT = XOS+235+320;
		YT = YT+140+30;
		LBL = 300;
		LBH = 14;
		TXL = 50;
		TXH = 20;
		//-------------------------------------------------------------------------
		JLabel LabelWheel = new JLabel("WHEEL :");
		LabelWheel.setBounds(XL+0, YL+0, LBL, LBH); // (X, Y, L, H)
		LabelWheel.setForeground(Color.RED);
		//LabelWheel.setForeground(Color.GRAY);
		contentPane.add(LabelWheel);
		//-------------------------------------------------------------------------
		JLabel Label35 = new JLabel("Default Wheel Perimeter (mm)");
		Label35.setBounds(XL+0, YL+20, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label35);

		TxtField35 = new JTextField();
		TxtField35.setText("2083");
		TxtField35.setBounds(XT+0, YT+20, TXL, TXH); // (X, Y, L, H)
		TxtField35.setBackground(Color.PINK);
		contentPane.add(TxtField35);
		TxtField35.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label36 = new JLabel("Default Wheel Speed Max (Km/h)");
		Label36.setBounds(XL+0, YL+40, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label36);

		TxtField36 = new JTextField();
		TxtField36.setText("45");
		TxtField36.setBounds(XT+0, YT+40, TXL, TXH); // (X, Y, L, H)
		TxtField36.setBackground(Color.PINK);
		contentPane.add(TxtField36);
		TxtField36.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label37 = new JLabel("VLCD6 Wheel Speed Factor");
		Label37.setBounds(XL+0, YL+60, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label37);

		TxtField37 = new JTextField();
		TxtField37.setText("315");
		TxtField37.setBounds(XT+0, YT+60, TXL, TXH); // (X, Y, L, H)
		TxtField37.setBackground(Color.YELLOW);
		TxtField37.setForeground(Color.GRAY);
		contentPane.add(TxtField37);
		TxtField37.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label38 = new JLabel("Wheel Speed Sensor Max PWM Ticks");
		Label38.setBounds(XL+0, YL+80, LBL, LBH); // (X, Y, L, H)
		Label38.setForeground(Color.GRAY);
		contentPane.add(Label38);

		TxtField38 = new JTextField();
		TxtField38.setText("1166");
		TxtField38.setBounds(XT+0, YT+80, TXL, TXH); // (X, Y, L, H)
		TxtField38.setForeground(Color.GRAY);
		contentPane.add(TxtField38);
		TxtField38.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label39 = new JLabel("Wheel Speed Sensor Min PWM Ticks");
		Label39.setBounds(XL+0, YL+100, LBL, LBH); // (X, Y, L, H)
		Label39.setForeground(Color.GRAY);
		contentPane.add(Label39);

		TxtField39 = new JTextField();
		TxtField39.setText("65534");
		//TxtField39.setText("32767");
		TxtField39.setBounds(XT+0, YT+100, TXL, TXH); // (X, Y, L, H)
		TxtField39.setForeground(Color.GRAY);
		contentPane.add(TxtField39);
		TxtField39.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label40 = new JLabel("Wheel Speed PI Controller KP Dividend");
		Label40.setBounds(XL+0, YL+120, LBL, LBH); // (X, Y, L, H)
		Label40.setForeground(Color.GRAY);
		contentPane.add(Label40);

		TxtField40 = new JTextField();
		TxtField40.setText("100");
		TxtField40.setBounds(XT+0, YT+120, TXL, TXH); // (X, Y, L, H)
		TxtField40.setForeground(Color.GRAY);
		contentPane.add(TxtField40);
		TxtField40.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label41 = new JLabel("Wheel Speed PI Controller KP Divisor");
		Label41.setBounds(XL+0, YL+140, LBL, LBH); // (X, Y, L, H)
		Label41.setForeground(Color.GRAY);
		contentPane.add(Label41);

		TxtField41 = new JTextField();
		TxtField41.setText("4");
		TxtField41.setBounds(XT+0, YT+140, TXL, TXH); // (X, Y, L, H)
		TxtField41.setForeground(Color.GRAY);
		contentPane.add(TxtField41);
		TxtField41.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label42 = new JLabel("Wheel Speed PI Controller KI Dividend");
		Label42.setBounds(XL+0, YL+160, LBL, LBH); // (X, Y, L, H)
		Label42.setForeground(Color.GRAY);
		contentPane.add(Label42);

		TxtField42 = new JTextField();
		TxtField42.setText("40");
		TxtField42.setBounds(XT+0, YT+160, TXL, TXH); // (X, Y, L, H)
		TxtField42.setForeground(Color.GRAY);
		contentPane.add(TxtField42);
		TxtField42.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label43 = new JLabel("Wheel Speed PI Controller KI Divisor");
		Label43.setBounds(XL+0, YL+180, LBL, LBH); // (X, Y, L, H)
		Label43.setForeground(Color.GRAY);
		contentPane.add(Label43);

		TxtField43 = new JTextField();
		TxtField43.setText("6");
		TxtField43.setBounds(XT+0, YT+180, TXL, TXH); // (X, Y, L, H)
		TxtField43.setForeground(Color.GRAY);
		contentPane.add(TxtField43);
		TxtField43.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label44 = new JLabel("Reserved");
		Label44.setBounds(XL+0, YL+200, LBL, LBH); // (X, Y, L, H)
		Label44.setForeground(Color.GRAY);
		contentPane.add(Label44);

		TxtField44 = new JTextField();
		TxtField44.setText("0");
		TxtField44.setBounds(XT+0, YT+200, TXL, TXH); // (X, Y, L, H)
		TxtField44.setEditable(false);
		//TxtField44.setBackground(Color.LIGHT_GRAY);
		TxtField44.setForeground(Color.GRAY);
		contentPane.add(TxtField44);
		TxtField44.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label45 = new JLabel("Reserved");
		Label45.setBounds(XL+0, YL+220, LBL, LBH); // (X, Y, L, H)
		Label45.setForeground(Color.GRAY);
		contentPane.add(Label45);

		TxtField45 = new JTextField();
		TxtField45.setText("0");
		TxtField45.setBounds(XT+0, YT+220, TXL, TXH); // (X, Y, L, H)
		TxtField45.setEditable(false);
		//TxtField45.setBackground(Color.LIGHT_GRAY);
		TxtField45.setForeground(Color.GRAY);
		contentPane.add(TxtField45);
		TxtField45.setColumns(10);
		
		//=============================================================================================
		// PAS
		//=============================================================================================
		XL = XOS+320;
		YL = YL+220+30;
		XT = XOS+235+320;
		YT = YT+220+30;
		LBL = 300;
		LBH = 14;
		TXL = 50;
		TXH = 20;
		//-------------------------------------------------------------------------
		JLabel LabelPAS = new JLabel("PAS :");
		LabelPAS.setBounds(XL+0, YL+0, LBL, LBH); // (X, Y, L, H)
		LabelPAS.setForeground(Color.RED);
		//LabelPAS.setForeground(Color.GRAY);
		contentPane.add(LabelPAS);		
		//-------------------------------------------------------------------------
		JLabel Label47 = new JLabel("PAS Number of Magnets");
		Label47.setBounds(XL+0, YL+20, LBL, LBH); // (X, Y, L, H)
		Label47.setForeground(Color.GRAY);
		contentPane.add(Label47);

		TxtField47 = new JTextField();
		TxtField47.setText("20");
		TxtField47.setBounds(XT+0, YT+20, TXL, TXH); // (X, Y, L, H)
		TxtField47.setForeground(Color.GRAY);
		contentPane.add(TxtField47);
		TxtField47.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label48 = new JLabel("Reserved");
		Label48.setBounds(XL+0, YL+40, LBL, LBH); // (X, Y, L, H)
		Label48.setForeground(Color.GRAY);
		contentPane.add(Label48);

		TxtField48 = new JTextField();
		TxtField48.setText("0");
		TxtField48.setBounds(XT+0, YT+40, TXL, TXH); // (X, Y, L, H)
		TxtField48.setEditable(false);
		//TxtField48.setBackground(Color.LIGHT_GRAY);
		TxtField48.setForeground(Color.GRAY);
		contentPane.add(TxtField48);
		TxtField48.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label49 = new JLabel("Reserved");
		Label49.setBounds(XL+0, YL+60, LBL, LBH); // (X, Y, L, H)
		Label49.setForeground(Color.GRAY);
		contentPane.add(Label49);

		TxtField49 = new JTextField();
		TxtField49.setText("0");
		TxtField49.setBounds(XT+0, YT+60, TXL, TXH); // (X, Y, L, H)
		TxtField49.setEditable(false);
		//TxtField49.setBackground(Color.LIGHT_GRAY);
		TxtField49.setForeground(Color.GRAY);
		contentPane.add(TxtField49);
		TxtField49.setColumns(10);

		//=============================================================================================
		// PEDAL ASSIST
		//=============================================================================================
		XL = XOS+320;
		YL = YL+60+30;
		XT = XOS+235+320;
		YT = YT+60+30;
		LBL = 300;
		LBH = 14;
		TXL = 50;
		TXH = 20;		
		//-------------------------------------------------------------------------
		JLabel LabelPedalAssist = new JLabel("PEDAL ASSIST :");
		LabelPedalAssist.setBounds(XL+0, YL+0, LBL, LBH); // (X, Y, L, H)
		LabelPedalAssist.setForeground(Color.RED);
		//LabelPedalAssist.setForeground(Color.GRAY);
		contentPane.add(LabelPedalAssist);
		//-------------------------------------------------------------------------
		JLabel Label61 = new JLabel("Default Assist Level Value (10 ... 500%)");
		Label61.setBounds(XL+0, YL+20, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label61);

		TxtField61 = new JTextField();
		TxtField61.setText("50");
		TxtField61.setBounds(XT+0, YT+20, TXL, TXH); // (X, Y, L, H)
		contentPane.add(TxtField61);
		TxtField61.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label62 = new JLabel("Assist Level 1-Eco (10 ... 500%)");
		Label62.setBounds(XL+0, YL+40, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label62);

		TxtField62 = new JTextField();
		TxtField62.setText("50");
		TxtField62.setBounds(XT+0, YT+40, TXL, TXH); // (X, Y, L, H)
		TxtField62.setBackground(Color.YELLOW);
		contentPane.add(TxtField62);
		TxtField62.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label63 = new JLabel("Assist Level 2-Tour (10 ... 500%)");
		Label63.setBounds(XL+0, YL+60, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label63);

		TxtField63 = new JTextField();
		TxtField63.setText("120");
		TxtField63.setBounds(XT+0, YT+60, TXL, TXH); // (X, Y, L, H)
		TxtField63.setBackground(Color.YELLOW);
		contentPane.add(TxtField63);
		TxtField63.setColumns(10);
		/*
		//-------------------------------------------------------------------------
		JLabel Label64 = new JLabel("Reserved");
		Label64.setBounds(XL+0, YL+120, LBL, LBH); // (X, Y, L, H)
		Label64.setForeground(Color.GRAY);
		contentPane.add(Label64);

		TxtField64 = new JTextField();
		TxtField64.setText("0");
		TxtField64.setBounds(XT+0, YT+120, TXL, TXH); // (X, Y, L, H)
		TxtField64.setEditable(false);
		//TxtField64.setBackground(Color.LIGHT_GRAY);
		TxtField64.setForeground(Color.GRAY);
		contentPane.add(TxtField64);
		TxtField64.setColumns(10);
		*/
		//-------------------------------------------------------------------------
		JLabel Label65 = new JLabel("Assist Level 3-Sport (10 ... 500%)");
		Label65.setBounds(XL+0, YL+80, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label65);

		TxtField65 = new JTextField();
		TxtField65.setText("210");
		TxtField65.setBounds(XT+0, YT+80, TXL, TXH); // (X, Y, L, H)
		TxtField65.setBackground(Color.YELLOW);
		contentPane.add(TxtField65);
		TxtField65.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label66 = new JLabel("Assist Level 4-Turbo (10 ... 500%)");
		Label66.setBounds(XL+0, YL+100, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label66);

		TxtField66 = new JTextField();
		TxtField66.setText("300");
		TxtField66.setBounds(XT+0, YT+100, TXL, TXH); // (X, Y, L, H)
		TxtField66.setBackground(Color.YELLOW);
		contentPane.add(TxtField66);
		TxtField66.setColumns(10);
		/*
		//-------------------------------------------------------------------------
		JLabel Label67 = new JLabel("Reserved");
		Label67.setBounds(XL+0, YL+120, LBL, LBH); // (X, Y, L, H)
		Label67.setForeground(Color.GRAY);
		contentPane.add(Label67);

		TxtField67 = new JTextField();
		TxtField67.setText("0");
		TxtField67.setBounds(XT+0, YT+120, TXL, TXH); // (X, Y, L, H)
		TxtField67.setEditable(false);
		//TxtField67.setBackground(Color.LIGHT_GRAY);
		TxtField67.setForeground(Color.GRAY);
		contentPane.add(TxtField67);
		TxtField67.setColumns(10);
		*/

		//=============================================================================================
		// THROTTLE
		//=============================================================================================
		XL = XOS+320+320;
		YL = YOS;
		XT = XOS+235+320+320;
		YT = YOS;
		LBL = 300;
		LBH = 14;
		TXL = 50;
		TXH = 20;	
		//-------------------------------------------------------------------------
		JLabel LabelTrottle = new JLabel("THROTTLE :");
		LabelTrottle.setBounds(XL+0, YL+0, LBL, LBH); // (X, Y, L, H)
		LabelTrottle.setForeground(Color.RED);
		//LabelTrottle.setForeground(Color.GRAY);
		contentPane.add(LabelTrottle);
		//-------------------------------------------------------------------------
		JLabel Label55 = new JLabel("ADC Throttle Threshold (0 ... 255)");
		Label55.setBounds(XL+0, YL+20, LBL, LBH); // (X, Y, L, H)
		Label55.setForeground(Color.GRAY);
		contentPane.add(Label55);

		TxtField55 = new JTextField();
		TxtField55.setText("10");
		TxtField55.setBounds(XT+0, YT+20, TXL, TXH); // (X, Y, L, H)
		TxtField55.setForeground(Color.GRAY);
		contentPane.add(TxtField55);
		TxtField55.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label56 = new JLabel("Throttle Filter Coefficient (0 ... 255)");
		Label56.setBounds(XL+0, YL+40, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label56);

		TxtField56 = new JTextField();
		TxtField56.setText("1");
		TxtField56.setBounds(XT+0, YT+40, TXL, TXH); // (X, Y, L, H)
		contentPane.add(TxtField56);
		TxtField56.setColumns(10);	
		//-------------------------------------------------------------------------
		JLabel Label57 = new JLabel("ADC Throttle Range Min Value (0 ... 255)");
		Label57.setBounds(XL+0, YL+60, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label57);

		TxtField57 = new JTextField();
		TxtField57.setText("47");
		TxtField57.setBounds(XT+0, YT+60, TXL, TXH); // (X, Y, L, H)
		contentPane.add(TxtField57);
		TxtField57.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label58 = new JLabel("ADC Throttle Range Max Value (0 ... 255)");
		Label58.setBounds(XL+0, YL+80, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label58);

		TxtField58 = new JTextField();
		TxtField58.setText("176");
		TxtField58.setBounds(XT+0, YT+80, TXL, TXH); // (X, Y, L, H)
		contentPane.add(TxtField58);
		TxtField58.setColumns(10);
		/*
		//-------------------------------------------------------------------------
		JLabel Label59 = new JLabel("Reserved");
		Label59.setBounds(XL+0, YL+100, LBL, LBH); // (X, Y, L, H)
		Label59.setForeground(Color.GRAY);
		contentPane.add(Label59);

		TxtField59 = new JTextField();
		TxtField59.setText("0");
		TxtField59.setBounds(XT+0, YT+100, TXL, TXH); // (X, Y, L, H)
		TxtField59.setEditable(false);
		//TxtField59.setBackground(Color.LIGHT_GRAY);
		TxtField59.setForeground(Color.GRAY);
		contentPane.add(TxtField59);
		TxtField59.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label60 = new JLabel("Reserved");
		Label60.setBounds(XL+0, YL+120, LBL, LBH); // (X, Y, L, H)
		Label60.setForeground(Color.GRAY);
		contentPane.add(Label60);

		TxtField60 = new JTextField();
		TxtField60.setText("0");
		TxtField60.setBounds(XT+0, YT+120, TXL, TXH); // (X, Y, L, H)
		TxtField60.setEditable(false);
		//TxtField60.setBackground(Color.LIGHT_GRAY);
		TxtField60.setForeground(Color.GRAY);
		contentPane.add(TxtField60);
		TxtField60.setColumns(10);
		*/
		
		//=============================================================================================
		// TORQUE SENSOR
		//=============================================================================================
		XL = XOS+320+320;
		YL = YL+80+30;
		XT = XOS+235+320+320;
		YT = YT+80+30;
		LBL = 300;
		LBH = 14;
		TXL = 50;
		TXH = 20;		
		//-------------------------------------------------------------------------
		JLabel LabelTorque = new JLabel("TORQUE SENSOR :");
		LabelTorque.setBounds(XL+0, YL+0, LBL, LBH); // (X, Y, L, H)
		LabelTorque.setForeground(Color.RED);
		//LabelTorque.setForeground(Color.GRAY);
		contentPane.add(LabelTorque);		
		//-------------------------------------------------------------------------
		JLabel Label50 = new JLabel("ADC Torque Sensor Threshold (0 ... 255)");
		Label50.setBounds(XL+0, YL+20, LBL, LBH); // (X, Y, L, H)
		Label50.setForeground(Color.GRAY);
		contentPane.add(Label50);

		TxtField50 = new JTextField();
		TxtField50.setText("6");
		TxtField50.setBounds(XT+0, YT+20, TXL, TXH); // (X, Y, L, H)
		TxtField50.setForeground(Color.GRAY);
		contentPane.add(TxtField50);
		TxtField50.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label51 = new JLabel("Pedal Torque Sensor Force per Unit (Nm)");
		Label51.setBounds(XL+0, YL+40, LBL, LBH); // (X, Y, L, H)
		Label51.setForeground(Color.GRAY);
		contentPane.add(Label51);

		TxtField51 = new JTextField();
		TxtField51.setText("0.52");
		TxtField51.setBounds(XT+0, YT+40, TXL, TXH); // (X, Y, L, H)
		TxtField51.setForeground(Color.GRAY);
		contentPane.add(TxtField51);
		TxtField51.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label52 = new JLabel("Reserved");
		Label52.setBounds(XL+0, YL+60, LBL, LBH); // (X, Y, L, H)
		Label52.setForeground(Color.GRAY);
		contentPane.add(Label52);

		TxtField52 = new JTextField();
		TxtField52.setText("0");
		TxtField52.setBounds(XT+0, YT+60, TXL, TXH); // (X, Y, L, H)
		TxtField52.setEditable(false);
		//TxtField52.setBackground(Color.LIGHT_GRAY);
		TxtField52.setForeground(Color.GRAY);
		contentPane.add(TxtField52);
		TxtField52.setColumns(10);

		//=============================================================================================
		// WALK ASSIST
		//=============================================================================================
		XL = XOS+320+320;
		YL = YL+60+30;
		XT = XOS+235+320+320;
		YT = YT+60+30;
		LBL = 300;
		LBH = 14;
		TXL = 50;
		TXH = 20;	
		//-------------------------------------------------------------------------
		JLabel LabelWalkAssist = new JLabel("WALK ASSIST:");
		LabelWalkAssist.setBounds(XL+0, YL+0, LBL, LBH); // (X, Y, L, H)
		LabelWalkAssist.setForeground(Color.RED);
		//LabelWalkAssist.setForeground(Color.GRAY);
		contentPane.add(LabelWalkAssist);
		//-------------------------------------------------------------------------
		JLabel Label68 = new JLabel("Walk Assist PWM Level 0 (max 100%)");
		Label68.setBounds(XL+0, YL+20, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label68);

		TxtField68 = new JTextField();
		TxtField68.setText("10");
		TxtField68.setBounds(XT+0, YT+20, TXL, TXH); // (X, Y, L, H)
		TxtField68.setBackground(Color.GREEN);
		contentPane.add(TxtField68);
		TxtField68.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label69 = new JLabel("Walk Assist PWM Level 1 (max 100%)");
		Label69.setBounds(XL+0, YL+40, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label69);

		TxtField69 = new JTextField();
		TxtField69.setText("13");
		TxtField69.setBounds(XT+0, YT+40, TXL, TXH); // (X, Y, L, H)
		TxtField69.setBackground(Color.GREEN);
		contentPane.add(TxtField69);
		TxtField69.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label70 = new JLabel("Walk Assist PWM Level 2 (max 100%)");
		Label70.setBounds(XL+0, YL+60, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label70);

		TxtField70 = new JTextField();
		TxtField70.setText("16");
		TxtField70.setBounds(XT+0, YT+60, TXL, TXH); // (X, Y, L, H)
		TxtField70.setBackground(Color.GREEN);
		contentPane.add(TxtField70);
		TxtField70.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label71 = new JLabel("Walk Assist PWM Level 3 (max 100%)");
		Label71.setBounds(XL+0, YL+80, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label71);

		TxtField71 = new JTextField();
		TxtField71.setText("19");
		TxtField71.setBounds(XT+0, YT+80, TXL, TXH); // (X, Y, L, H)
		TxtField71.setBackground(Color.GREEN);
		contentPane.add(TxtField71);
		TxtField71.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label72 = new JLabel("Walk Assist PWM Level 4 (max 100%)");
		Label72.setBounds(XL+0, YL+100, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label72);

		TxtField72 = new JTextField();
		TxtField72.setText("22");
		TxtField72.setBounds(XT+0, YT+100, TXL, TXH); // (X, Y, L, H)
		TxtField72.setBackground(Color.GREEN);
		contentPane.add(TxtField72);
		TxtField72.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label73 = new JLabel("Walk Assist Current (max 100%)");
		Label73.setBounds(XL+0, YL+120, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label73);

		TxtField73 = new JTextField();
		TxtField73.setText("10");
		TxtField73.setBounds(XT+0, YT+120, TXL, TXH); // (X, Y, L, H)
		TxtField73.setBackground(Color.GREEN);
		contentPane.add(TxtField73);
		TxtField73.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label74 = new JLabel("Walk Assist Max Ramp (0.0 ... 25.5 sec)");
		Label74.setBounds(XL+0, YL+140, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label74);

		TxtField74 = new JTextField();
		TxtField74.setText("2.0");
		TxtField74.setBounds(XT+0, YT+140, TXL, TXH); // (X, Y, L, H)
		TxtField74.setBackground(Color.GREEN);
		contentPane.add(TxtField74);
		TxtField74.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label53 = new JLabel("Walk Assist Range Min Value (0 ... 255)");
		Label53.setBounds(XL+0, YL+160, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label53);

		TxtField53 = new JTextField();
		TxtField53.setText("0");
		TxtField53.setBounds(XT+0, YT+160, TXL, TXH); // (X, Y, L, H)
		TxtField53.setBackground(Color.GREEN);
		contentPane.add(TxtField53);
		TxtField53.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label54 = new JLabel("Walk Assist Range Max Value (0 ... 255)");
		Label54.setBounds(XL+0, YL+180, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label54);

		TxtField54 = new JTextField();
		TxtField54.setText("100");
		TxtField54.setBounds(XT+0, YT+180, TXL, TXH); // (X, Y, L, H)
		TxtField54.setBackground(Color.GREEN);
		contentPane.add(TxtField54);
		TxtField54.setColumns(10);		
		
		//=============================================================================================
		// OFFROAD MODE
		//=============================================================================================
		XL = XOS+320+320;
		YL = YL+180+30;
		XT = XOS+235+320+320;
		YT = YT+180+30;
		LBL = 300;
		LBH = 14;
		TXL = 50;
		TXH = 20;	
		//-------------------------------------------------------------------------
		JLabel LabelOffroad = new JLabel("OFFROAD MODE :");
		LabelOffroad.setBounds(XL+0, YL+0, LBL, LBH); // (X, Y, L, H)
		LabelOffroad.setForeground(Color.RED);
		//LabelOffroad.setForeground(Color.GRAY);
		contentPane.add(LabelOffroad);
		//-------------------------------------------------------------------------
		JLabel Label75 = new JLabel("Offroad Speed Limit (Km/h)");
		Label75.setBounds(XL+0, YL+20, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label75);

		TxtField75 = new JTextField();
		TxtField75.setText("25");
		TxtField75.setBounds(XT+0, YT+20, TXL, TXH); // (X, Y, L, H)
		contentPane.add(TxtField75);
		TxtField75.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label76 = new JLabel("Offroad Power Limit (Watt)");
		Label76.setBounds(XL+0, YL+40, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label76);

		TxtField76 = new JTextField();
		TxtField76.setText("250");
		TxtField76.setBounds(XT+0, YT+40, TXL, TXH); // (X, Y, L, H)
		contentPane.add(TxtField76);
		TxtField76.setColumns(10);

		//=============================================================================================
		// MOTOR POWER BOOST
		//=============================================================================================
		XL = XOS+320+320;
		YL = YL+40+30;
		XT = XOS+235+320+320;
		YT = YT+40+30;
		LBL = 300;
		LBH = 14;
		TXL = 50;
		TXH = 20;	
		//-------------------------------------------------------------------------
		JLabel LabelMotorBoost = new JLabel("MOTOR POWER BOOST :");
		LabelMotorBoost.setBounds(XL+0, YL+0, LBL, LBH); // (X, Y, L, H)
		LabelMotorBoost.setForeground(Color.RED);
		//LabelMotorBoost.setForeground(Color.GRAY);
		contentPane.add(LabelMotorBoost);
		//-------------------------------------------------------------------------
		CheckBox02 = new JCheckBox("Limit Motor Boost to Max Power");
		CheckBox02.setSelected(true);
		CheckBox02.setBounds(XL+0, YL+20, 250, 20);
		contentPane.add(CheckBox02);		
		//-------------------------------------------------------------------------
		JLabel Label77 = new JLabel("Startup Motor Boost Level 1 (max 100%)");
		Label77.setBounds(XL+0, YL+40, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label77);

		TxtField77 = new JTextField();
		TxtField77.setText("15");
		TxtField77.setBounds(XT+0, YT+40, TXL, TXH); // (X, Y, L, H)
		TxtField77.setBackground(Color.CYAN);
		contentPane.add(TxtField77);
		TxtField77.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label78 = new JLabel("Startup Motor Boost Level 2 (max 100%)");
		Label78.setBounds(XL+0, YL+60, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label78);

		TxtField78 = new JTextField();
		TxtField78.setText("43");
		TxtField78.setBounds(XT+0, YT+60, TXL, TXH); // (X, Y, L, H)
		TxtField78.setBackground(Color.CYAN);
		contentPane.add(TxtField78);
		TxtField78.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label79 = new JLabel("Startup Motor Boost Level 3 (max 100%)");
		Label79.setBounds(XL+0, YL+80, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label79);

		TxtField79 = new JTextField();
		TxtField79.setText("72");
		TxtField79.setBounds(XT+0, YT+80, TXL, TXH); // (X, Y, L, H)
		TxtField79.setBackground(Color.CYAN);
		contentPane.add(TxtField79);
		TxtField79.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label80 = new JLabel("Startup Motor Boost Level 4 (max 100%)");
		Label80.setBounds(XL+0, YL+100, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label80);

		TxtField80 = new JTextField();
		TxtField80.setText("100");
		TxtField80.setBounds(XT+0, YT+100, TXL, TXH); // (X, Y, L, H)
		TxtField80.setBackground(Color.CYAN);
		contentPane.add(TxtField80);
		TxtField80.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label81 = new JLabel("Startup Motor Boost Time (max 25.5 sec)");
		Label81.setBounds(XL+0, YL+120, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label81);

		TxtField81 = new JTextField();
		TxtField81.setText("2.0");
		TxtField81.setBounds(XT+0, YT+120, TXL, TXH); // (X, Y, L, H)
		TxtField81.setBackground(Color.CYAN);
		contentPane.add(TxtField81);
		TxtField81.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label82 = new JLabel("Startup Motor Boost Fade (max 25.5 sec)");
		Label82.setBounds(XL+0, YL+140, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label82);

		TxtField82 = new JTextField();
		TxtField82.setText("3.5");
		TxtField82.setBounds(XT+0, YT+140, TXL, TXH); // (X, Y, L, H)
		TxtField82.setBackground(Color.CYAN);
		contentPane.add(TxtField82);
		TxtField82.setColumns(10);

		//=============================================================================================
		// CRUISE CONTROL
		//=============================================================================================
		XL = XOS+320+320+320;
		YL = YOS;
		XT = XOS+235+320+320+320;
		YT = YOS;
		LBL = 300;
		LBH = 14;
		TXL = 50;
		TXH = 20;	
		//-------------------------------------------------------------------------
		JLabel LabelCruiseControl = new JLabel("CRUISE CONTROL :");
		LabelCruiseControl.setBounds(XL+0, YL+0, LBL, LBH); // (X, Y, L, H)
		LabelCruiseControl.setForeground(Color.RED);
		//LabelCruiseControl.setForeground(Color.GRAY);
		contentPane.add(LabelCruiseControl);
		//-------------------------------------------------------------------------
		JLabel Label83 = new JLabel("Cruise Control Min (0 ... 255)");
		Label83.setBounds(XL+0, YL+20, LBL, LBH); // (X, Y, L, H)
		Label83.setForeground(Color.GRAY);
		contentPane.add(Label83);

		TxtField83 = new JTextField();
		TxtField83.setText("20");
		TxtField83.setBounds(XT+0, YT+20, TXL, TXH); // (X, Y, L, H)
		TxtField83.setEditable(false);
		//TxtField83.setBackground(Color.LIGHT_GRAY);
		TxtField83.setForeground(Color.GRAY);
		contentPane.add(TxtField83);
		TxtField83.setColumns(10);		
		//-------------------------------------------------------------------------
		JLabel Label84 = new JLabel("Reserved");
		Label84.setBounds(XL+0, YL+40, LBL, LBH); // (X, Y, L, H)
		Label84.setForeground(Color.GRAY);
		contentPane.add(Label84);

		TxtField84 = new JTextField();
		TxtField84.setText("0");
		TxtField84.setBounds(XT+0, YT+40, TXL, TXH); // (X, Y, L, H)
		TxtField84.setEditable(false);
		//TxtField84.setBackground(Color.LIGHT_GRAY);
		TxtField84.setForeground(Color.GRAY);
		contentPane.add(TxtField84);
		TxtField84.setColumns(10);		

		//=============================================================================================
		// MOTOR TEMPERATURE
		//=============================================================================================
		XL = XOS+320+320+320;
		YL = YL+40+30;
		XT = XOS+235+320+320+320;
		YT = YT+40+30;
		LBL = 300;
		LBH = 14;
		TXL = 50;
		TXH = 20;	
		//-------------------------------------------------------------------------
		JLabel LabelMotorTemperature = new JLabel("MOTOR TEMPERATURE :");
		LabelMotorTemperature.setBounds(XL+0, YL+0, LBL, LBH); // (X, Y, L, H)
		LabelMotorTemperature.setForeground(Color.RED);
		//LabelMotorTemperature.setForeground(Color.GRAY);
		contentPane.add(LabelMotorTemperature);
		//-------------------------------------------------------------------------
		JLabel Label85 = new JLabel("Motor Temperature Min Limit (Celsius)");
		Label85.setBounds(XL+0, YL+20, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label85);

		TxtField85 = new JTextField();
		TxtField85.setText("75");
		TxtField85.setBounds(XT+0, YT+20, TXL, TXH); // (X, Y, L, H)
		TxtField85.setBackground(Color.RED);
		TxtField85.setForeground(Color.WHITE);
		contentPane.add(TxtField85);
		TxtField85.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label86 = new JLabel("Motor Temperature Max Limit (Celsius)");
		Label86.setBounds(XL+0, YL+40, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label86);

		TxtField86 = new JTextField();
		TxtField86.setText("85");
		TxtField86.setBounds(XT+0, YT+40, TXL, TXH); // (X, Y, L, H)
		TxtField86.setBackground(Color.RED);
		TxtField86.setForeground(Color.WHITE);
		contentPane.add(TxtField86);
		TxtField86.setColumns(10);
		//-------------------------------------------------------------------------
		JLabel Label87 = new JLabel("Motor Temperature Filter (0 ... 255)");
		Label87.setBounds(XL+0, YL+60, LBL, LBH); // (X, Y, L, H)
		contentPane.add(Label87);

		TxtField87 = new JTextField();
		TxtField87.setText("4");
		TxtField87.setBounds(XT+0, YT+60, TXL, TXH); // (X, Y, L, H)
		TxtField87.setBackground(Color.RED);
		TxtField87.setForeground(Color.WHITE);
		contentPane.add(TxtField87);
		TxtField87.setColumns(10);

		//=============================================================================================
		// ENABLES
		//=============================================================================================
		XL = XOS+320+320+320;
		YL = YL+60+30;
		XT = XOS+235+320+320+320;
		YT = YT+60+30;
		LBL = 300;
		LBH = 14;
		TXL = 50;
		TXH = 20;
		//-------------------------------------------------------------------------
		JLabel LabelEnablesConfig = new JLabel("ENABLES :");
		LabelEnablesConfig.setBounds(XL+0, YL+0, LBL, LBH); // (X, Y, L, H)
		LabelEnablesConfig.setForeground(Color.RED);
		//LabelEnablesConfig.setForeground(Color.GRAY);
		contentPane.add(LabelEnablesConfig);
		//-------------------------------------------------------------------------
		rdbtnVLCD6 = new JRadioButton("VLCD6");
		rdbtnVLCD6.setSelected(true);
		DisplayType.add(rdbtnVLCD6);
		rdbtnVLCD6.setBounds(XL+0, YL+20, 100, 20); // (X, Y, L, H)
		contentPane.add(rdbtnVLCD6);

		rdbtnVLCD6.addItemListener(new ItemListener()
		{
			@Override
			public void itemStateChanged(ItemEvent e)
			{
				updateDependiencies();
			}
		});		
		
		rdbtnKTLCD3 = new JRadioButton("KT-LCD3");
		rdbtnKTLCD3.setSelected(false);
		DisplayType.add(rdbtnKTLCD3);
		rdbtnKTLCD3.setBounds(XL+100, YL+20, 100, 20); // (X, Y, L, H)
		contentPane.add(rdbtnKTLCD3);
		
		rdbtnKTLCD3.addItemListener(new ItemListener()
		{
			@Override
			public void itemStateChanged(ItemEvent e)
			{
				updateDependiencies();
			}
		});		

		rdbtnBTooth = new JRadioButton("Reserved");
		rdbtnBTooth.setSelected(false);
		DisplayType.add(rdbtnBTooth);
		rdbtnBTooth.setBounds(XL+200, YL+20, 100, 20); // (X, Y, L, H)
		rdbtnBTooth.setForeground(Color.GRAY);
		contentPane.add(rdbtnBTooth);
		
		rdbtnBTooth.addItemListener(new ItemListener()
		{
			@Override
			public void itemStateChanged(ItemEvent e)
			{
				updateDependiencies();
			}
		});
		//-------------------------------------------------------------------------
		CheckBox03 = new JCheckBox("Throttle");
		CheckBox03.setSelected(false);
		CheckBox03.setBounds(XL+0, YL+40, 150, 20); // (X, Y, L, H)
		contentPane.add(CheckBox03);

		CheckBox03.addItemListener(new ItemListener()
		{
			@Override
			public void itemStateChanged(ItemEvent e)
			{
				updateDependiencies();
			}
		});		

		CheckBox04 = new JCheckBox("Brake Sensors");
		CheckBox04.setSelected(false);
		CheckBox04.setBounds(XL+150, YL+40, 150, 20); // (X, Y, L, H)
		contentPane.add(CheckBox04);
		//-------------------------------------------------------------------------
		YL = YL+5;
		
		rdbtnLights = new JRadioButton("Lights (Button Dw)");
		rdbtnLights.setSelected(true);
		ButtonLights.add(rdbtnLights);
		rdbtnLights.setBounds(XL+0, YL+60, 150, 20); // (X, Y, L, H)
		rdbtnLights.setBackground(Color.BLUE);
		contentPane.add(rdbtnLights);		

		rdbtnOffroad = new JRadioButton("Offroad (Button Dw)");
		rdbtnOffroad.setSelected(false);
		ButtonLights.add(rdbtnOffroad);
		rdbtnOffroad.setBounds(XL+150, YL+60, 150, 20); // (X, Y, L, H)
		rdbtnOffroad.setBackground(Color.MAGENTA);
		contentPane.add(rdbtnOffroad);
		
		rdbtnOffroad.addItemListener(new ItemListener()
		{
			@Override
			public void itemStateChanged(ItemEvent e)
			{
				updateDependiencies();
			}
		});	
		//-------------------------------------------------------------------------
		CheckBox05 = new JCheckBox("Offroad On Startup");
		CheckBox05.setSelected(false);
		CheckBox05.setBounds(XL+0, YL+80, 150, 20); // (X, Y, L, H)
		CheckBox05.setBackground(Color.MAGENTA);
		contentPane.add(CheckBox05);

		CheckBox06 = new JCheckBox("Offroad Limit");
		CheckBox06.setSelected(false);
		CheckBox06.setBounds(XL+150, YL+80, 150, 20); // (X, Y, L, H)
		CheckBox06.setBackground(Color.MAGENTA);
		contentPane.add(CheckBox06);
		//-------------------------------------------------------------------------
		CheckBox09 = new JCheckBox("Wheel Perimeter");
		CheckBox09.setSelected(true);
		CheckBox09.setBounds(XL+0, YL+100, 150, 20); // (X, Y, L, H)
		CheckBox09.setBackground(Color.PINK);
		contentPane.add(CheckBox09);
		
		CheckBox09.addItemListener(new ItemListener()
		{
			@Override
			public void itemStateChanged(ItemEvent e)
			{
				updateDependiencies();
			}
		});		
		
		CheckBox10 = new JCheckBox("Wheel Max Speed");
		CheckBox10.setSelected(true);
		CheckBox10.setBounds(XL+150, YL+100, 150, 20); // (X, Y, L, H)
		CheckBox10.setBackground(Color.PINK);
		contentPane.add(CheckBox10);	

		CheckBox10.addItemListener(new ItemListener()
		{
			@Override
			public void itemStateChanged(ItemEvent e)
			{
				updateDependiencies();
			}
		});		
		//-------------------------------------------------------------------------
		CheckBox07 = new JCheckBox("Walk Assist");
		CheckBox07.setSelected(true);
		CheckBox07.setBounds(XL+0, YL+120, 150, 20); // (X, Y, L, H)
		CheckBox07.setBackground(Color.GREEN);
		contentPane.add(CheckBox07);
		
		CheckBox07.addItemListener(new ItemListener()
		{
			@Override
			public void itemStateChanged(ItemEvent e)
			{
				updateDependiencies();
			}
		});		

		CheckBox08 = new JCheckBox("VLCD6 Always On");
		CheckBox08.setSelected(false);
		CheckBox08.setBounds(XL+150, YL+120, 150, 20); // (X, Y, L, H)
		CheckBox08.setBackground(Color.ORANGE);
		contentPane.add(CheckBox08);
		
		CheckBox08.addItemListener(new ItemListener()
		{
			@Override
			public void itemStateChanged(ItemEvent e)
			{
				updateDependiencies();
			}
		});		
		//-------------------------------------------------------------------------
		CheckBox11 = new JCheckBox("Motor Working Flag");
		CheckBox11.setSelected(true);
		CheckBox11.setBounds(XL+0, YL+140, 150, 20); // (X, Y, L, H)
		CheckBox11.setBackground(Color.ORANGE);
		contentPane.add(CheckBox11);
		
		CheckBox11.addItemListener(new ItemListener()
		{
			@Override
			public void itemStateChanged(ItemEvent e)
			{
				updateDependiencies();
			}
		});		
		
		CheckBox12 = new JCheckBox("Wheel Turning Flag");
		CheckBox12.setSelected(true);
		CheckBox12.setBounds(XL+150, YL+140, 150, 20); // (X, Y, L, H)
		CheckBox12.setBackground(Color.ORANGE);
		contentPane.add(CheckBox12);

		CheckBox12.addItemListener(new ItemListener()
		{
			@Override
			public void itemStateChanged(ItemEvent e)
			{
				updateDependiencies();
			}
		});		
		//-------------------------------------------------------------------------
		rdbtnBoost = new JRadioButton("Boost (Button Dw)");
		rdbtnBoost.setSelected(false);
		ButtonLights.add(rdbtnBoost);
		rdbtnBoost.setBounds(XL+0, YL+160, 150, 20); // (X, Y, L, H)
		rdbtnBoost.setBackground(Color.CYAN);
		contentPane.add(rdbtnBoost);
		
		rdbtnBoost.addItemListener(new ItemListener()
		{
			@Override
			public void itemStateChanged(ItemEvent e)
			{
				updateDependiencies();
			}
		});			
		
		CheckBox14 = new JCheckBox("Temperature Limit");
		CheckBox14.setSelected(true);
		CheckBox14.setBounds(XL+150, YL+160, 150, 20); // (X, Y, L, H)
		CheckBox14.setBackground(Color.RED);
		contentPane.add(CheckBox14);

		CheckBox14.addItemListener(new ItemListener()
		{
			@Override
			public void itemStateChanged(ItemEvent e)
			{
				updateDependiencies();
			}
		});		
		//-------------------------------------------------------------------------		
		rdbtnBoostSpeed = new JRadioButton("Boost at Speed 0");
		rdbtnBoostSpeed.setSelected(true);
		BoostState.add(rdbtnBoostSpeed);
		rdbtnBoostSpeed.setBounds(XL+0, YL+180, 150, 20); // (X, Y, L, H)
		rdbtnBoostSpeed.setBackground(Color.CYAN);
		contentPane.add(rdbtnBoostSpeed);		
		
		rdbtnBoostCadence = new JRadioButton("Boost at Cadence 0");
		rdbtnBoostCadence.setSelected(false);
		BoostState.add(rdbtnBoostCadence);
		rdbtnBoostCadence.setBounds(XL+150, YL+180, 150, 20); // (X, Y, L, H)
		rdbtnBoostCadence.setBackground(Color.CYAN);
		contentPane.add(rdbtnBoostCadence);
		//-------------------------------------------------------------------------		
		JLabel Label88 = new JLabel("Magic Byte");
		Label88.setBounds(XOS+1073, YOS+600, LBL, LBH); // (X, Y, L, H)
		Label88.setForeground(Color.BLUE);
		contentPane.add(Label88);

		TxtField88 = new JTextField();
		TxtField88.setText("170");
		TxtField88.setBounds(XOS+1073, YOS+618, 65, TXH); // (X, Y, L, H)
		//TxtField88.setBackground(Color.BLUE);
		TxtField88.setForeground(Color.BLUE);
		contentPane.add(TxtField88);
		TxtField88.setColumns(10);		
		//-------------------------------------------------------------------------
		/*
		cbResetEeprom = new JCheckBox("Write eeprom magic byte (will reset eeprom)");
		cbResetEeprom.setSelected(true);
		cbResetEeprom.setBounds(XOS+960, YOS+575, 300, 20);
		contentPane.add(cbResetEeprom);*/
		//-------------------------------------------------------------------------
		cbSaveIni = new JCheckBox("Save file .ini (when compile)");
		cbSaveIni.setSelected(false);
		cbSaveIni.setBounds(XOS+960, YOS+575, 300, 20);
		contentPane.add(cbSaveIni);		
		//-------------------------------------------------------------------------
		JButton btnWriteoptionsbyte = new JButton("Program");
		btnWriteoptionsbyte.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnWriteoptionsbyte.setForeground(Color.BLUE);
		btnWriteoptionsbyte.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				try
				{
					Process process = Runtime.getRuntime().exec("cmd /c start Program");
				} 
				catch (IOException e1)
				{
					//txtThrottlemin.setText("Error");
					//e1.printStackTrace();
				}
			}
		});
		btnWriteoptionsbyte.setBounds(XOS+1160, YOS+600, 100, 40);
		contentPane.add(btnWriteoptionsbyte);
		//-------------------------------------------------------------------------		
		/*
		JButton btnWriteoptionsbyte = new JButton("Write Option Bytes");
		btnWriteoptionsbyte.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnWriteoptionsbyte.setForeground(Color.BLUE);
		btnWriteoptionsbyte.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				{
					int n = JOptionPane.showConfirmDialog(
							null,
							"If you run this function with a brand new controller, the original firmware will be erased. This can't be undone. Are you sure?",
							"",
							JOptionPane.YES_NO_OPTION);

					if (n == JOptionPane.YES_OPTION)
					{
						try
						{
							Process process = Runtime.getRuntime().exec("cmd /c start WriteOptionBytes");
						} 
						catch (IOException e1)
						{
							//txtThrottlemin.setText("Error");
							//e1.printStackTrace();
						}
					}
					else
					{
						JOptionPane.showMessageDialog(null, "Goodbye");
					}

					// Saving code here
				}
			}
		});
		btnWriteoptionsbyte.setBounds(XOS+1090, YOS+600, 170, 40);
		contentPane.add(btnWriteoptionsbyte);*/		
		//-------------------------------------------------------------------------		
		btnWriteConfiguration = new JButton("Compile");
		btnWriteConfiguration.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				PrintWriter pWriter = null;
				PrintWriter iWriter = null;
				try
				{
					//FileWriter fw = new FileWriter("settings.ini");
					//BufferedWriter bw = new BufferedWriter(fw);
					
					if (cbSaveIni.isSelected())
					{
						File newFile = new File(experimentalSettingsDir + File.separator + "TSDZ2_Config_" + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".ini");
						experimentalSettingsFilesModel.add(0, new FileContainer(newFile));
						iWriter = new PrintWriter(new BufferedWriter(new FileWriter(newFile)));
						cbSaveIni.setSelected(false);
					}
					else
					{
						File newFile = new File("src/controller/config.h");
						iWriter = new PrintWriter(new BufferedWriter(new FileWriter(newFile)));
					}
					
					pWriter = new PrintWriter(new BufferedWriter(new FileWriter("src/controller/config.h")));
					pWriter.println("/*\r\n"
							+ " * config.h\r\n"
							+ " *\r\n"
							+ " *  Automatically created by TSDZ2 Controller's Parameters Configurator\r\n"
							+ " *  Author: marcoq\r\n"
							+ " */\r\n"
							+ "\r\n"
							+ "#ifndef CONFIG_H_\r\n"
							+ "#define CONFIG_H_\r\n");
					
					pWriter.println(""
							+ "//=================================================================================================\r\n"					
							+ "// ENABLES\r\n"
							+ "//=================================================================================================");

					String text_to_save;

					if (rdbtnVLCD6.isSelected())
						text_to_save = "#define ENABLE_VLCD6 1";
					else
						text_to_save = "#define ENABLE_VLCD6 0";
					pWriter.println(text_to_save);
					iWriter.println(rdbtnVLCD6.isSelected());	

					if (rdbtnKTLCD3.isSelected())
						text_to_save = "#define ENABLE_KTLCD3 1";
					else
						text_to_save = "#define ENABLE_KTLCD3 0";
					pWriter.println(text_to_save);
					iWriter.println(rdbtnKTLCD3.isSelected());

					if (rdbtnBTooth.isSelected())
						text_to_save = "#define ENABLE_BLUETOOTH 1";
					else
						text_to_save = "#define ENABLE_BLUETOOTH 0";
					pWriter.println(text_to_save);
					iWriter.println(rdbtnBTooth.isSelected());
					//-------------------------------------------------------------------
					if (rdbtnLights.isSelected())
						text_to_save = "#define ENABLE_LIGHTS_FROM_VLCD6 1";
					else
						text_to_save = "#define ENABLE_LIGHTS_FROM_VLCD6 0";
					pWriter.println(text_to_save);
					iWriter.println(rdbtnLights.isSelected());	

					if (rdbtnBoost.isSelected())
						text_to_save = "#define ENABLE_POWER_BOOST_FROM_VLCD6 1";
					else
						text_to_save = "#define ENABLE_POWER_BOOST_FROM_VLCD6 0";
					pWriter.println(text_to_save);
					iWriter.println(rdbtnBoost.isSelected());

					if (rdbtnOffroad.isSelected())
						text_to_save = "#define ENABLE_OFFROAD_FROM_VLCD6 1";
					else
						text_to_save = "#define ENABLE_OFFROAD_FROM_VLCD6 0";
					pWriter.println(text_to_save);
					iWriter.println(rdbtnOffroad.isSelected());	
					//-------------------------------------------------------------------
					if (CheckBox07.isSelected())
						text_to_save = "#define ENABLE_WALK_ASSIST_FROM_VLCD6 1";
					else
						text_to_save = "#define ENABLE_WALK_ASSIST_FROM_VLCD6 0";
					pWriter.println(text_to_save);
					iWriter.println(CheckBox07.isSelected());					
					
					if (CheckBox04.isSelected())
						text_to_save = "#define ENABLE_BRAKE_SENSOR 1";
					else
						text_to_save = "#define ENABLE_BRAKE_SENSOR 0";
					pWriter.println(text_to_save);
					iWriter.println(CheckBox04.isSelected());

					if (CheckBox03.isSelected())
						text_to_save = "#define ENABLE_THROTTLE 1";
					else
						text_to_save = "#define ENABLE_THROTTLE 0";
					pWriter.println(text_to_save);
					iWriter.println(CheckBox03.isSelected());					
					//-------------------------------------------------------------------
					if (CheckBox09.isSelected())
						text_to_save = "#define ENABLE_WHEEL_PERIMETER_FROM_VLCD6	1";
					else
						text_to_save = "#define ENABLE_WHEEL_PERIMETER_FROM_VLCD6 0";
					pWriter.println(text_to_save);
					iWriter.println(CheckBox09.isSelected());

					if (CheckBox10.isSelected())
						text_to_save = "#define ENABLE_WHEEL_MAX_SPEED_FROM_VLCD6 1";
					else
						text_to_save = "#define ENABLE_WHEEL_MAX_SPEED_FROM_VLCD6 0";
					pWriter.println(text_to_save);
					iWriter.println(CheckBox10.isSelected());
					//-------------------------------------------------------------------
					if (CheckBox11.isSelected())
						text_to_save = "#define ENABLE_MOTOR_WORKING_FLAG 1";
					else
						text_to_save = "#define ENABLE_MOTOR_WORKING_FLAG 0";
					pWriter.println(text_to_save);
					iWriter.println(CheckBox11.isSelected());

					if (CheckBox12.isSelected())
						text_to_save = "#define ENABLE_WHEEL_TURNING_FLAG 1";
					else
						text_to_save = "#define ENABLE_WHEEL_TURNING_FLAG 0";
					pWriter.println(text_to_save);
					iWriter.println(CheckBox12.isSelected());
					
					if (CheckBox08.isSelected())
						text_to_save = "#define ENABLE_VLCD6_ALWAYS_ON 1";
					else
						text_to_save = "#define ENABLE_VLCD6_ALWAYS_ON 0";
					pWriter.println(text_to_save);
					iWriter.println(CheckBox08.isSelected());					
					//-------------------------------------------------------------------
					if (rdbtnOffroad.isSelected())
						text_to_save = "#define OFFROAD_FEATURE_ENABLED 1";
					else
						text_to_save = "#define OFFROAD_FEATURE_ENABLED 0";
					pWriter.println(text_to_save);
					iWriter.println(rdbtnOffroad.isSelected());

					if (CheckBox05.isSelected())
						text_to_save = "#define OFFROAD_ON_STARTUP_ENABLED 1";
					else
						text_to_save = "#define OFFROAD_ON_STARTUP_ENABLED 0";
					pWriter.println(text_to_save);
					iWriter.println(CheckBox05.isSelected());
					
					if (CheckBox06.isSelected())
						text_to_save = "#define OFFROAD_POWER_LIMIT_ENABLED 1";
					else
						text_to_save = "#define OFFROAD_POWER_LIMIT_ENABLED 0";
					pWriter.println(text_to_save);
					iWriter.println(CheckBox06.isSelected());
					//-------------------------------------------------------------------
					if (CheckBox14.isSelected())
						text_to_save = "#define TEMPERATURE_LIMIT_FEATURE_ENABLED 1";
					else
						text_to_save = "#define TEMPERATURE_LIMIT_FEATURE_ENABLED 0";
					pWriter.println(text_to_save);
					iWriter.println(CheckBox14.isSelected());					
					//-------------------------------------------------------------------
					if (rdbtnBoostSpeed.isSelected())
						text_to_save = "#define STARTUP_BOOST_WHEN_SPEED_IS_ZERO 1";
					else
						text_to_save = "#define STARTUP_BOOST_WHEN_SPEED_IS_ZERO 0";
					pWriter.println(text_to_save);
					iWriter.println(rdbtnBoostSpeed.isSelected());					
					
					if (rdbtnBoostCadence.isSelected())
						text_to_save = "#define STARTUP_BOOST_WHEN_CADENCE_IS_ZERO 1";
					else
						text_to_save = "#define STARTUP_BOOST_WHEN_CADENCE_IS_ZERO 0";
					pWriter.println(text_to_save);
					iWriter.println(rdbtnBoostCadence.isSelected());
					
					pWriter.println(""
							+ "//=================================================================================================\r\n"
							+ "// BATTERY\r\n"
							+ "//=================================================================================================");	
							
					text_to_save = "#define ADC_BATTERY_CURRENT_MAX_LIMIT " + TxtField01.getText();
					iWriter.println(TxtField01.getText());
					pWriter.println(text_to_save);							

					text_to_save = "#define TARGET_MAX_BATTERY_POWER (uint16_t) " + TxtField02.getText();
					iWriter.println(TxtField02.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define BATTERY_MAX_CURRENT_FLOAT " + TxtField03.getText();
					iWriter.println(TxtField03.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define BATTERY_CELLS_NUMBER (uint8_t) " + TxtField04.getText();
					iWriter.println(TxtField04.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define BATTERY_LOW_VOLTAGE_CUT_OFF_DIV10 " + TxtField05.getText();
					iWriter.println(TxtField05.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define BATTERY_PACK_RESISTANCE (uint16_t) " + TxtField06.getText();
					iWriter.println(TxtField06.getText());
					pWriter.println(text_to_save);
					//-------------------------------------------------------------------
					text_to_save = "#define ADC_BATTERY_VOLTAGE " + TxtField07.getText();
					iWriter.println(TxtField07.getText());
					pWriter.println(text_to_save);
					//-------------------------------------------------------------------
					text_to_save = "#define LI_ION_CELL_VOLTS_100 " + TxtField08.getText();
					iWriter.println(TxtField08.getText());
					pWriter.println(text_to_save);					
					
					text_to_save = "#define LI_ION_CELL_VOLTS_83 " + TxtField09.getText();
					iWriter.println(TxtField09.getText());
					pWriter.println(text_to_save);					
					
					text_to_save = "#define LI_ION_CELL_VOLTS_50 " + TxtField10.getText();
					iWriter.println(TxtField10.getText());
					pWriter.println(text_to_save);					
					
					text_to_save = "#define LI_ION_CELL_VOLTS_17 " + TxtField11.getText();
					iWriter.println(TxtField11.getText());
					pWriter.println(text_to_save);					
					
					text_to_save = "#define LI_ION_CELL_VOLTS_10 " + TxtField12.getText();
					iWriter.println(TxtField12.getText());
					pWriter.println(text_to_save);					
					
					text_to_save = "#define LI_ION_CELL_VOLTS_0 " + TxtField13.getText();
					iWriter.println(TxtField13.getText());
					pWriter.println(text_to_save);					
					//-------------------------------------------------------------------
					text_to_save = "#define SOC_BATTERY_VOLTAGE_FILTER_COEFFICIENT (uint8_t) " + TxtField14.getText();
					iWriter.println(TxtField14.getText());
					pWriter.println(text_to_save);					
					
					text_to_save = "#define SOC_BATTERY_CURRENT_FILTER_COEFFICIENT (uint8_t) " + TxtField15.getText();
					iWriter.println(TxtField15.getText());
					pWriter.println(text_to_save);
					
					text_to_save = "#define SOC_ADC_BATTERY_VOLTAGE_PER_ADC_STEP " + TxtField16.getText();
					iWriter.println(TxtField16.getText());
					pWriter.println(text_to_save);
					//-------------------------------------------------------------------
					text_to_save = "#define READ_BATTERY_VOLTAGE_FILTER_COEFFICIENT	(uint8_t)" + TxtField17.getText();
					iWriter.println(TxtField17.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define READ_BATTERY_CURRENT_FILTER_COEFFICIENT (uint8_t)" + TxtField18.getText();
					iWriter.println(TxtField18.getText());
					pWriter.println(text_to_save);					
					
					pWriter.println(""
							+ "//=================================================================================================\r\n"
							+ "// MOTOR\r\n"
							+ "//=================================================================================================");

					if (rdbtnMot36V.isSelected())
						text_to_save = "#define MOTOR_TYPE_36V 1";
					else
						text_to_save = "#define MOTOR_TYPE_36V 0";
					pWriter.println(text_to_save);
					iWriter.println(rdbtnMot36V.isSelected());	

					if (rdbtnMot48V.isSelected())
						text_to_save = "#define MOTOR_TYPE_48V 1";
					else
						text_to_save = "#define MOTOR_TYPE_48V 0";
					pWriter.println(text_to_save);
					iWriter.println(rdbtnMot48V.isSelected());
					
					if (CheckBox13.isSelected())
						text_to_save = "#define EXPERIMENTAL_HIGH_CADENCE_MODE 1";
					else
						text_to_save = "#define EXPERIMENTAL_HIGH_CADENCE_MODE 0";
					pWriter.println(text_to_save);
					iWriter.println(CheckBox13.isSelected());					
					
					if (CheckBox01.isSelected())
						text_to_save = "#define MOTOR_ASSISTANCE_WITHOUT_PEDAL_ROTATION 1";
					else
						text_to_save = "#define MOTOR_ASSISTANCE_WITHOUT_PEDAL_ROTATION 0";
					pWriter.println(text_to_save);
					iWriter.println(CheckBox01.isSelected());					

					text_to_save = "#define MOTOR_MAX_POWER (uint16_t) " + TxtField19.getText();
					iWriter.println(TxtField19.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define MOTOR_PHASE_CURRENT_MAX_AMP " + TxtField20.getText();
					iWriter.println(TxtField20.getText());
					pWriter.println(text_to_save);
					//-------------------------------------------------------------------
					text_to_save = "#define MOTOR_ROTOR_OFFSET_ANGLE (uint8_t) " + TxtField21.getText();
					iWriter.println(TxtField21.getText());
					pWriter.println(text_to_save);
					//-------------------------------------------------------------------
					text_to_save = "#define MOTOR_ROTOR_ERPS_START_INTERPOLATION_60_DEGREES	(uint8_t) " + TxtField22.getText();
					iWriter.println(TxtField22.getText());
					pWriter.println(text_to_save);
					//-------------------------------------------------------------------
					text_to_save = "#define MOTOR_OVER_SPEED_ERPS (uint16_t) " + TxtField23.getText();
					iWriter.println(TxtField23.getText());
					pWriter.println(text_to_save);
					
					text_to_save = "#define MOTOR_OVER_SPEED_ERPS_EXPERIMENTAL (uint16_t) " + TxtField24.getText();
					iWriter.println(TxtField24.getText());
					pWriter.println(text_to_save);
					//-------------------------------------------------------------------
					text_to_save = "#define RESERVED " + TxtField25.getText();
					iWriter.println(TxtField25.getText());
					//pWriter.println(text_to_save);

					text_to_save = "#define RESERVED " + TxtField26.getText();
					iWriter.println(TxtField26.getText());
					//pWriter.println(text_to_save);
					
					/*
					text_to_save = "#define RESERVED " + TxtField27.getText();
					iWriter.println(TxtField27.getText());
					//pWriter.println(text_to_save);*/					

					pWriter.println(""
							+ "//=================================================================================================\r\n"
							+ "// PWM DUTY CYCLE\r\n"
							+ "//=================================================================================================");
							
					text_to_save = "#define PWM_CYCLES_SECOND (uint16_t) " + TxtField28.getText();
					iWriter.println(TxtField28.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define PWM_DUTY_CYCLE_MIN (uint8_t) " + TxtField29.getText();
					iWriter.println(TxtField29.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define PWM_DUTY_CYCLE_MAX (uint8_t) " + TxtField30.getText();
					iWriter.println(TxtField30.getText());
					pWriter.println(text_to_save);
					//-------------------------------------------------------------------
					text_to_save = "#define PWM_DUTY_CYCLE_RAMP_UP_DIV1000 " + TxtField31.getText();
					iWriter.println(TxtField31.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define PWM_DUTY_CYCLE_RAMP_DOWN_DIV1000 " + TxtField32.getText();
					iWriter.println(TxtField32.getText());
					pWriter.println(text_to_save);
					//-------------------------------------------------------------------
					text_to_save = "#define RESERVED " + TxtField33.getText();
					iWriter.println(TxtField33.getText());
					//pWriter.println(text_to_save);

					text_to_save = "#define RESERVED " + TxtField34.getText();
					iWriter.println(TxtField34.getText());
					//pWriter.println(text_to_save);
					
					pWriter.println(""
							+ "//=================================================================================================\r\n"
							+ "// WHEEL\r\n"
							+ "//=================================================================================================");

					text_to_save = "#define WHEEL_PERIMETER (uint16_t) " + TxtField35.getText();
					iWriter.println(TxtField35.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define WHEEL_MAX_SPEED (uint8_t) " + TxtField36.getText();
					iWriter.println(TxtField36.getText());
					pWriter.println(text_to_save);					

					text_to_save = "#define VLCD6_WHEEL_SPEED_FACTOR (uint16_t) " + TxtField37.getText();
					iWriter.println(TxtField37.getText());
					pWriter.println(text_to_save);					
					//-------------------------------------------------------------------
					text_to_save = "#define WHEEL_SPEED_SENSOR_MAX_PWM_CYCLE_TICKS (uint16_t) " + TxtField38.getText();
					iWriter.println(TxtField38.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define WHEEL_SPEED_SENSOR_MIN_PWM_CYCLE_TICKS (uint16_t) " + TxtField39.getText();
					iWriter.println(TxtField39.getText());
					pWriter.println(text_to_save);
					//-------------------------------------------------------------------
					text_to_save = "#define WHEEL_SPEED_PI_CONTROLLER_KP_DIVIDEND (uint8_t) " + TxtField40.getText();
					iWriter.println(TxtField40.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define WHEEL_SPEED_PI_CONTROLLER_KP_DIVISOR (uint8_t) " + TxtField41.getText();
					iWriter.println(TxtField41.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define WHEEL_SPEED_PI_CONTROLLER_KI_DIVIDEND (uint8_t) " + TxtField42.getText();
					iWriter.println(TxtField42.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define WHEEL_SPEED_PI_CONTROLLER_KI_DIVISOR (uint8_t) " + TxtField43.getText();
					iWriter.println(TxtField43.getText());
					pWriter.println(text_to_save);
					//-------------------------------------------------------------------
					text_to_save = "#define RESERVED " + TxtField44.getText();
					iWriter.println(TxtField44.getText());
					//pWriter.println(text_to_save);

					text_to_save = "#define RESERVED " + TxtField45.getText();
					iWriter.println(TxtField45.getText());
					//pWriter.println(text_to_save);
					
					pWriter.println(""
							+ "//=================================================================================================\r\n"
							+ "// PAS\r\n"
							+ "//=================================================================================================");					

					text_to_save = "#define PAS_NUMBER_MAGNETS (uint8_t) " + TxtField47.getText();
					iWriter.println(TxtField47.getText());
					pWriter.println(text_to_save);
					//-------------------------------------------------------------------
					text_to_save = "#define RESERVED " + TxtField48.getText();
					iWriter.println(TxtField48.getText());
					//pWriter.println(text_to_save);

					text_to_save = "#define RESERVED " + TxtField49.getText();
					iWriter.println(TxtField49.getText());
					//pWriter.println(text_to_save);
					
					pWriter.println(""
							+ "//=================================================================================================\r\n"
							+ "// PEDAL ASSIST\r\n"
							+ "//=================================================================================================");

					text_to_save = "#define ASSIST_LEVEL_FACTOR (uint16_t) " + TxtField61.getText();
					iWriter.println(TxtField61.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define ASSIST_LEVEL_FACTOR_X10_1 (uint16_t) " + TxtField62.getText();
					iWriter.println(TxtField62.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define ASSIST_LEVEL_FACTOR_X10_2 (uint16_t) " + TxtField63.getText();
					iWriter.println(TxtField63.getText());
					pWriter.println(text_to_save);
					/*
					text_to_save = "#define RESERVED " + TxtField64.getText();
					iWriter.println(TxtField64.getText());
					//pWriter.println(text_to_save);*/					
					
					text_to_save = "#define ASSIST_LEVEL_FACTOR_X10_3 (uint16_t) " + TxtField65.getText();
					iWriter.println(TxtField65.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define ASSIST_LEVEL_FACTOR_X10_4 (uint16_t) " + TxtField66.getText();
					iWriter.println(TxtField66.getText());
					pWriter.println(text_to_save);

					pWriter.println(""
							+ "//=================================================================================================\r\n"
							+ "// THROTTLE\r\n"
							+ "//=================================================================================================");
							
					text_to_save = "#define ADC_THROTTLE_THRESHOLD (uint8_t) " + TxtField55.getText();
					iWriter.println(TxtField55.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define THROTTLE_FILTER_COEFFICIENT (uint8_t) " + TxtField56.getText();
					iWriter.println(TxtField56.getText());
					pWriter.println(text_to_save);
					
					text_to_save = "#define ADC_THROTTLE_MIN_VALUE (uint8_t) " + TxtField57.getText();
					iWriter.println(TxtField57.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define ADC_THROTTLE_MAX_VALUE (uint8_t) " + TxtField58.getText();
					iWriter.println(TxtField58.getText());
					pWriter.println(text_to_save);					
					
					pWriter.println(""
							+ "//=================================================================================================\r\n"
							+ "// TORQUE SENSOR\r\n"
							+ "//=================================================================================================");
							
					text_to_save = "#define ADC_TORQUE_SENSOR_THRESHOLD (uint8_t) " + TxtField50.getText();
					iWriter.println(TxtField50.getText());
					pWriter.println(text_to_save);							

					text_to_save = "#define PEDAL_TORQUE_SENSOR_UNIT " + TxtField51.getText();
					iWriter.println(TxtField51.getText());
					pWriter.println(text_to_save);					
					//-------------------------------------------------------------------
					text_to_save = "#define RESERVED " + TxtField52.getText();
					iWriter.println(TxtField52.getText());
					//pWriter.println(text_to_save);

					text_to_save = "#define RESERVED " + TxtField53.getText();
					iWriter.println(TxtField53.getText());
					//pWriter.println(text_to_save);

					text_to_save = "#define RESERVED " + TxtField54.getText();
					iWriter.println(TxtField54.getText());
					//pWriter.println(text_to_save);

					pWriter.println(""
							+ "//=================================================================================================\r\n"
							+ "// WALK ASSIST\r\n"
							+ "//=================================================================================================");
							
					text_to_save = "#define WALK_ASSIST_PWM_LEVEL_0 (uint8_t) " + TxtField68.getText();
					iWriter.println(TxtField68.getText());
					pWriter.println(text_to_save);					

					text_to_save = "#define WALK_ASSIST_PWM_LEVEL_1 (uint8_t) " + TxtField69.getText();
					iWriter.println(TxtField69.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define WALK_ASSIST_PWM_LEVEL_2 (uint8_t) " + TxtField70.getText();
					iWriter.println(TxtField70.getText());
					pWriter.println(text_to_save);
					
					text_to_save = "#define WALK_ASSIST_PWM_LEVEL_3 (uint8_t) " + TxtField71.getText();
					iWriter.println(TxtField71.getText());
					pWriter.println(text_to_save);					

					text_to_save = "#define WALK_ASSIST_PWM_LEVEL_4 (uint8_t) " + TxtField72.getText();
					iWriter.println(TxtField72.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define WALK_ASSIST_PERCENTAGE_CURRENT (uint8_t) " + TxtField73.getText();
					iWriter.println(TxtField73.getText());
					pWriter.println(text_to_save);
					
					text_to_save = "#define WALK_ASSIST_MAX_RAMP_TIME_DIV10 " + TxtField74.getText();
					iWriter.println(TxtField74.getText());
					pWriter.println(text_to_save);
					
					text_to_save = "#define WALK_ASSIST_MIN_VALUE (uint8_t) " + TxtField53.getText();
					iWriter.println(TxtField53.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define WALK_ASSIST_MAX_VALUE (uint8_t) " + TxtField54.getText();
					iWriter.println(TxtField54.getText());
					pWriter.println(text_to_save);

					pWriter.println(""
							+ "//=================================================================================================\r\n"
							+ "// OFFROAD MODE\r\n"
							+ "//=================================================================================================");

					text_to_save = "#define OFFROAD_SPEED_LIMIT (uint8_t) " + TxtField75.getText();
					iWriter.println(TxtField75.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define OFFROAD_POWER_LIMIT (uint16_t) " + TxtField76.getText();
					iWriter.println(TxtField76.getText());
					pWriter.println(text_to_save);

					pWriter.println(""
							+ "//=================================================================================================\r\n"
							+ "// MOTOR POWER BOOST\r\n"
							+ "//=================================================================================================");
							
					if (CheckBox02.isSelected())
						text_to_save = "#define STARTUP_MOTOR_POWER_BOOST_LIMIT_MAX_POWER 1";
					else
						text_to_save = "#define STARTUP_MOTOR_POWER_BOOST_LIMIT_MAX_POWER 0";
					pWriter.println(text_to_save);
					iWriter.println(CheckBox02.isSelected());							

					text_to_save = "#define STARTUP_MOTOR_BOOST_ASSIST_LEVEL_PERCENT_1 (uint8_t) " + TxtField77.getText();
					iWriter.println(TxtField77.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define STARTUP_MOTOR_BOOST_ASSIST_LEVEL_PERCENT_2 (uint8_t) " + TxtField78.getText();
					iWriter.println(TxtField78.getText());
					pWriter.println(text_to_save);
					
					text_to_save = "#define STARTUP_MOTOR_BOOST_ASSIST_LEVEL_PERCENT_3 (uint8_t) " + TxtField79.getText();
					iWriter.println(TxtField79.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define STARTUP_MOTOR_BOOST_ASSIST_LEVEL_PERCENT_4 (uint8_t) " + TxtField80.getText();
					iWriter.println(TxtField80.getText());
					pWriter.println(text_to_save);					

					text_to_save = "#define STARTUP_MOTOR_POWER_BOOST_TIME_DIV10 " + TxtField81.getText();
					iWriter.println(TxtField81.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define STARTUP_MOTOR_POWER_BOOST_FADE_TIME_DIV10 " + TxtField82.getText();
					iWriter.println(TxtField82.getText());
					pWriter.println(text_to_save);

					pWriter.println(""
							+ "//=================================================================================================\r\n"
							+ "// CRUISE CONTROL\r\n"
							+ "//=================================================================================================");

					text_to_save = "#define CRUISE_CONTROL_MIN (uint8_t) " + TxtField83.getText();
					iWriter.println(TxtField83.getText());
					pWriter.println(text_to_save);
					//-------------------------------------------------------------------
					text_to_save = "#define RESERVED " + TxtField84.getText();
					iWriter.println(TxtField84.getText());
					//pWriter.println(text_to_save);
					
					pWriter.println(""
							+ "//=================================================================================================\r\n"
							+ "// MOTOR TEMPERATURE\r\n"
							+ "//=================================================================================================");					
					
					text_to_save = "#define MOTOR_TEMPERATURE_MIN_VALUE_LIMIT (uint8_t) " + TxtField85.getText();
					iWriter.println(TxtField85.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define MOTOR_TEMPERATURE_MAX_VALUE_LIMIT (uint8_t) " + TxtField86.getText();
					iWriter.println(TxtField86.getText());
					pWriter.println(text_to_save);

					text_to_save = "#define READ_MOTOR_TEMPERATURE_FILTER_COEFFICIENT (uint8_t) " + TxtField87.getText();
					iWriter.println(TxtField87.getText());
					pWriter.println(text_to_save);
					
					pWriter.println(""
							+ "//=================================================================================================\r\n"
							+ "// MAGIC BYTE\r\n"
							+ "//=================================================================================================");
							
					text_to_save = "#define MAGIC_BYTE (uint8_t) " + TxtField88.getText();
					iWriter.println(TxtField88.getText());
					pWriter.println(text_to_save);							
							
					pWriter.println("\r\n#endif /* CONFIG_H_ */");
					iWriter.close();							
				} 
				catch (IOException ioe)
				{
					ioe.printStackTrace();
				}
				finally
				{
					if (pWriter != null)
					{
						pWriter.flush();
						pWriter.close();
					}
				}
				try
				{
					Process process = Runtime.getRuntime().exec("cmd /c start Compile");
				} 
				catch (IOException e1)
				{
					//txtThrottlemin.setText("Error");
					e1.printStackTrace();
				}
			}
		});
		
		btnWriteConfiguration.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnWriteConfiguration.setForeground(Color.BLUE);
		btnWriteConfiguration.setBounds(XOS+960, YOS+600, 90, 40);
		contentPane.add(btnWriteConfiguration);

		if (lastSettingsFile != null)
		{
			try
			{
				loadSettings(lastSettingsFile);
			} 
			catch (Exception ex)
			{

			}
			provenSettingsList.clearSelection();
			experimentalSettingsList.clearSelection();
		}

		updateDependiencies();
	}
}
